﻿namespace Proj3W
{
    partial class FrmPrin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPrin));
            this.arquivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clienteEmpresaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.candidatoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vagasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ferramentasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calendárioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calculadoraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.windowsExplorerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editorDeTextoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ajudaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sobreOSistemaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton10 = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.arquivoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.fecharFormulárioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastroToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.clienteEmpresaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.candidatoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.vagaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ferramentasToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.calendáriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calculadoraToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.windowsExplorerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.iToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.editorDeTextoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ajudaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.sobreOSistemaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // arquivoToolStripMenuItem
            // 
            this.arquivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sairToolStripMenuItem});
            this.arquivoToolStripMenuItem.Font = new System.Drawing.Font("Perpetua Titling MT", 12F);
            this.arquivoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("arquivoToolStripMenuItem.Image")));
            this.arquivoToolStripMenuItem.Name = "arquivoToolStripMenuItem";
            this.arquivoToolStripMenuItem.Size = new System.Drawing.Size(114, 23);
            this.arquivoToolStripMenuItem.Text = "Arquivo";
            this.arquivoToolStripMenuItem.ToolTipText = "Arquivo";
            this.arquivoToolStripMenuItem.MouseMove += new System.Windows.Forms.MouseEventHandler(this.arquivoToolStripMenuItem_MouseMove);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("sairToolStripMenuItem.Image")));
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F)));
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(276, 24);
            this.sairToolStripMenuItem.Text = "Fechar Sistema";
            this.sairToolStripMenuItem.ToolTipText = "Fechar Sistema";
            this.sairToolStripMenuItem.MouseMove += new System.Windows.Forms.MouseEventHandler(this.sairToolStripMenuItem_MouseMove);
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // cadastroToolStripMenuItem
            // 
            this.cadastroToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clienteEmpresaToolStripMenuItem,
            this.candidatoToolStripMenuItem,
            this.vagasToolStripMenuItem});
            this.cadastroToolStripMenuItem.Font = new System.Drawing.Font("Perpetua Titling MT", 12F);
            this.cadastroToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("cadastroToolStripMenuItem.Image")));
            this.cadastroToolStripMenuItem.Name = "cadastroToolStripMenuItem";
            this.cadastroToolStripMenuItem.Size = new System.Drawing.Size(126, 23);
            this.cadastroToolStripMenuItem.Text = "Cadastro";
            this.cadastroToolStripMenuItem.ToolTipText = "Cadastro";
            this.cadastroToolStripMenuItem.MouseMove += new System.Windows.Forms.MouseEventHandler(this.cadastroToolStripMenuItem_MouseMove);
            // 
            // clienteEmpresaToolStripMenuItem
            // 
            this.clienteEmpresaToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("clienteEmpresaToolStripMenuItem.Image")));
            this.clienteEmpresaToolStripMenuItem.Name = "clienteEmpresaToolStripMenuItem";
            this.clienteEmpresaToolStripMenuItem.Size = new System.Drawing.Size(224, 24);
            this.clienteEmpresaToolStripMenuItem.Text = "Clientes Empresa";
            this.clienteEmpresaToolStripMenuItem.ToolTipText = "Clientes Empresa";
            this.clienteEmpresaToolStripMenuItem.MouseMove += new System.Windows.Forms.MouseEventHandler(this.clienteEmpresaToolStripMenuItem_MouseMove);
            this.clienteEmpresaToolStripMenuItem.Click += new System.EventHandler(this.clienteEmpresaToolStripMenuItem_Click);
            // 
            // candidatoToolStripMenuItem
            // 
            this.candidatoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("candidatoToolStripMenuItem.Image")));
            this.candidatoToolStripMenuItem.Name = "candidatoToolStripMenuItem";
            this.candidatoToolStripMenuItem.Size = new System.Drawing.Size(224, 24);
            this.candidatoToolStripMenuItem.Text = "Candidatos";
            this.candidatoToolStripMenuItem.ToolTipText = "Candidatos";
            this.candidatoToolStripMenuItem.MouseMove += new System.Windows.Forms.MouseEventHandler(this.candidatoToolStripMenuItem_MouseMove);
            this.candidatoToolStripMenuItem.Click += new System.EventHandler(this.candidatoToolStripMenuItem_Click);
            // 
            // vagasToolStripMenuItem
            // 
            this.vagasToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("vagasToolStripMenuItem.Image")));
            this.vagasToolStripMenuItem.Name = "vagasToolStripMenuItem";
            this.vagasToolStripMenuItem.Size = new System.Drawing.Size(224, 24);
            this.vagasToolStripMenuItem.Text = "Vagas";
            this.vagasToolStripMenuItem.ToolTipText = "Vagas";
            this.vagasToolStripMenuItem.MouseMove += new System.Windows.Forms.MouseEventHandler(this.vagasToolStripMenuItem_MouseMove);
            this.vagasToolStripMenuItem.Click += new System.EventHandler(this.vagasToolStripMenuItem_Click);
            // 
            // ferramentasToolStripMenuItem
            // 
            this.ferramentasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.calendárioToolStripMenuItem,
            this.calculadoraToolStripMenuItem,
            this.windowsExplorerToolStripMenuItem,
            this.iToolStripMenuItem,
            this.editorDeTextoToolStripMenuItem});
            this.ferramentasToolStripMenuItem.Font = new System.Drawing.Font("Perpetua Titling MT", 12F);
            this.ferramentasToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("ferramentasToolStripMenuItem.Image")));
            this.ferramentasToolStripMenuItem.Name = "ferramentasToolStripMenuItem";
            this.ferramentasToolStripMenuItem.Size = new System.Drawing.Size(149, 23);
            this.ferramentasToolStripMenuItem.Text = "Ferramentas";
            this.ferramentasToolStripMenuItem.ToolTipText = "Ferramentas";
            this.ferramentasToolStripMenuItem.MouseMove += new System.Windows.Forms.MouseEventHandler(this.ferramentasToolStripMenuItem_MouseMove);
            // 
            // calendárioToolStripMenuItem
            // 
            this.calendárioToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("calendárioToolStripMenuItem.Image")));
            this.calendárioToolStripMenuItem.Name = "calendárioToolStripMenuItem";
            this.calendárioToolStripMenuItem.Size = new System.Drawing.Size(246, 24);
            this.calendárioToolStripMenuItem.Text = "Calendário";
            this.calendárioToolStripMenuItem.ToolTipText = "Calendário";
            this.calendárioToolStripMenuItem.MouseMove += new System.Windows.Forms.MouseEventHandler(this.calendárioToolStripMenuItem_MouseMove);
            this.calendárioToolStripMenuItem.Click += new System.EventHandler(this.calendárioToolStripMenuItem_Click);
            // 
            // calculadoraToolStripMenuItem
            // 
            this.calculadoraToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("calculadoraToolStripMenuItem.Image")));
            this.calculadoraToolStripMenuItem.Name = "calculadoraToolStripMenuItem";
            this.calculadoraToolStripMenuItem.Size = new System.Drawing.Size(246, 24);
            this.calculadoraToolStripMenuItem.Text = "Calculadora";
            this.calculadoraToolStripMenuItem.ToolTipText = "Calculadora";
            this.calculadoraToolStripMenuItem.MouseMove += new System.Windows.Forms.MouseEventHandler(this.calculadoraToolStripMenuItem_MouseMove);
            this.calculadoraToolStripMenuItem.Click += new System.EventHandler(this.calculadoraToolStripMenuItem_Click);
            // 
            // windowsExplorerToolStripMenuItem
            // 
            this.windowsExplorerToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("windowsExplorerToolStripMenuItem.Image")));
            this.windowsExplorerToolStripMenuItem.Name = "windowsExplorerToolStripMenuItem";
            this.windowsExplorerToolStripMenuItem.Size = new System.Drawing.Size(246, 24);
            this.windowsExplorerToolStripMenuItem.Text = "Windows Explorer";
            this.windowsExplorerToolStripMenuItem.ToolTipText = "Windows Explorer";
            this.windowsExplorerToolStripMenuItem.MouseMove += new System.Windows.Forms.MouseEventHandler(this.windowsExplorerToolStripMenuItem_MouseMove);
            this.windowsExplorerToolStripMenuItem.Click += new System.EventHandler(this.windowsExplorerToolStripMenuItem_Click);
            // 
            // iToolStripMenuItem
            // 
            this.iToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("iToolStripMenuItem.Image")));
            this.iToolStripMenuItem.Name = "iToolStripMenuItem";
            this.iToolStripMenuItem.Size = new System.Drawing.Size(246, 24);
            this.iToolStripMenuItem.Text = "Internet Explorer";
            this.iToolStripMenuItem.ToolTipText = "Internet Explorer";
            this.iToolStripMenuItem.MouseMove += new System.Windows.Forms.MouseEventHandler(this.iToolStripMenuItem_MouseMove);
            this.iToolStripMenuItem.Click += new System.EventHandler(this.iToolStripMenuItem_Click);
            // 
            // editorDeTextoToolStripMenuItem
            // 
            this.editorDeTextoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("editorDeTextoToolStripMenuItem.Image")));
            this.editorDeTextoToolStripMenuItem.Name = "editorDeTextoToolStripMenuItem";
            this.editorDeTextoToolStripMenuItem.Size = new System.Drawing.Size(246, 24);
            this.editorDeTextoToolStripMenuItem.Text = "Editor de Texto";
            this.editorDeTextoToolStripMenuItem.ToolTipText = "Editor de Texto";
            this.editorDeTextoToolStripMenuItem.MouseMove += new System.Windows.Forms.MouseEventHandler(this.editorDeTextoToolStripMenuItem_MouseMove);
            this.editorDeTextoToolStripMenuItem.Click += new System.EventHandler(this.editorDeTextoToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.arquivoToolStripMenuItem,
            this.cadastroToolStripMenuItem,
            this.ferramentasToolStripMenuItem,
            this.ajudaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(755, 27);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ajudaToolStripMenuItem
            // 
            this.ajudaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sobreOSistemaToolStripMenuItem});
            this.ajudaToolStripMenuItem.Font = new System.Drawing.Font("Perpetua Titling MT", 12F);
            this.ajudaToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("ajudaToolStripMenuItem.Image")));
            this.ajudaToolStripMenuItem.Name = "ajudaToolStripMenuItem";
            this.ajudaToolStripMenuItem.Size = new System.Drawing.Size(89, 23);
            this.ajudaToolStripMenuItem.Text = "Ajuda";
            this.ajudaToolStripMenuItem.ToolTipText = "Ajuda";
            this.ajudaToolStripMenuItem.MouseMove += new System.Windows.Forms.MouseEventHandler(this.ajudaToolStripMenuItem_MouseMove);
            // 
            // sobreOSistemaToolStripMenuItem
            // 
            this.sobreOSistemaToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("sobreOSistemaToolStripMenuItem.Image")));
            this.sobreOSistemaToolStripMenuItem.Name = "sobreOSistemaToolStripMenuItem";
            this.sobreOSistemaToolStripMenuItem.Size = new System.Drawing.Size(216, 24);
            this.sobreOSistemaToolStripMenuItem.Text = "Sobre o Sistema";
            this.sobreOSistemaToolStripMenuItem.ToolTipText = "Sobre o Sistema";
            this.sobreOSistemaToolStripMenuItem.MouseMove += new System.Windows.Forms.MouseEventHandler(this.sobreOSistemaToolStripMenuItem_MouseMove);
            this.sobreOSistemaToolStripMenuItem.Click += new System.EventHandler(this.sobreOSistemaToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripSeparator1,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripSeparator2,
            this.toolStripButton5,
            this.toolStripButton6,
            this.toolStripButton7,
            this.toolStripButton8,
            this.toolStripButton9,
            this.toolStripSeparator3,
            this.toolStripButton10});
            this.toolStrip1.Location = new System.Drawing.Point(0, 27);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(755, 33);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.AutoSize = false;
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.ToolTipText = "Fechar Sistema";
            this.toolStripButton1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.sairToolStripMenuItem_MouseMove);
            this.toolStripButton1.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 33);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.AutoSize = false;
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton2.Text = "toolStripButton2";
            this.toolStripButton2.ToolTipText = "Cadatro Clientes Empresa";
            this.toolStripButton2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.clienteEmpresaToolStripMenuItem_MouseMove);
            this.toolStripButton2.Click += new System.EventHandler(this.clienteEmpresaToolStripMenuItem_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.AutoSize = false;
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton3.Text = "toolStripButton3";
            this.toolStripButton3.ToolTipText = "Cadastro Candidatos";
            this.toolStripButton3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.candidatoToolStripMenuItem_MouseMove);
            this.toolStripButton3.Click += new System.EventHandler(this.candidatoToolStripMenuItem_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.AutoSize = false;
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton4.Text = "toolStripButton4";
            this.toolStripButton4.ToolTipText = "Cadastro Vagas";
            this.toolStripButton4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.vagasToolStripMenuItem_MouseMove);
            this.toolStripButton4.Click += new System.EventHandler(this.vagasToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 33);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.AutoSize = false;
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton5.Text = "toolStripButton5";
            this.toolStripButton5.ToolTipText = "Calendário";
            this.toolStripButton5.MouseMove += new System.Windows.Forms.MouseEventHandler(this.calendárioToolStripMenuItem_MouseMove);
            this.toolStripButton5.Click += new System.EventHandler(this.calendárioToolStripMenuItem_Click);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.AutoSize = false;
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton6.Text = "toolStripButton6";
            this.toolStripButton6.ToolTipText = "Calculadora";
            this.toolStripButton6.MouseMove += new System.Windows.Forms.MouseEventHandler(this.calculadoraToolStripMenuItem_MouseMove);
            this.toolStripButton6.Click += new System.EventHandler(this.calculadoraToolStripMenuItem_Click);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.AutoSize = false;
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton7.Text = "toolStripButton7";
            this.toolStripButton7.ToolTipText = "Windows Explorer";
            this.toolStripButton7.MouseMove += new System.Windows.Forms.MouseEventHandler(this.windowsExplorerToolStripMenuItem_MouseMove);
            this.toolStripButton7.Click += new System.EventHandler(this.windowsExplorerToolStripMenuItem_Click);
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.AutoSize = false;
            this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton8.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton8.Image")));
            this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton8.Text = "toolStripButton8";
            this.toolStripButton8.ToolTipText = "Internet Explorer";
            this.toolStripButton8.MouseMove += new System.Windows.Forms.MouseEventHandler(this.iToolStripMenuItem_MouseMove);
            this.toolStripButton8.Click += new System.EventHandler(this.iToolStripMenuItem_Click);
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.AutoSize = false;
            this.toolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton9.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton9.Image")));
            this.toolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton9.Text = "toolStripButton9";
            this.toolStripButton9.ToolTipText = "Editor de Texto";
            this.toolStripButton9.MouseMove += new System.Windows.Forms.MouseEventHandler(this.editorDeTextoToolStripMenuItem_MouseMove);
            this.toolStripButton9.Click += new System.EventHandler(this.editorDeTextoToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 33);
            // 
            // toolStripButton10
            // 
            this.toolStripButton10.AutoSize = false;
            this.toolStripButton10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton10.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton10.Image")));
            this.toolStripButton10.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton10.Name = "toolStripButton10";
            this.toolStripButton10.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton10.Text = "toolStripButton10";
            this.toolStripButton10.ToolTipText = "Sobre o Sistema";
            this.toolStripButton10.MouseMove += new System.Windows.Forms.MouseEventHandler(this.sobreOSistemaToolStripMenuItem_MouseMove);
            this.toolStripButton10.Click += new System.EventHandler(this.sobreOSistemaToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3});
            this.statusStrip1.Location = new System.Drawing.Point(0, 395);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(755, 24);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(100, 19);
            this.toolStripStatusLabel1.Text = "Bem-Vindo";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Font = new System.Drawing.Font("Perpetua Titling MT", 12F);
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(213, 19);
            this.toolStripStatusLabel2.Text = "toolStripStatusLabel2";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Font = new System.Drawing.Font("Perpetua Titling MT", 12F);
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(212, 19);
            this.toolStripStatusLabel3.Text = "toolStripStatusLabel3";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.arquivoToolStripMenuItem1,
            this.cadastroToolStripMenuItem1,
            this.ferramentasToolStripMenuItem1,
            this.ajudaToolStripMenuItem1});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(189, 100);
            // 
            // arquivoToolStripMenuItem1
            // 
            this.arquivoToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fecharFormulárioToolStripMenuItem});
            this.arquivoToolStripMenuItem1.Font = new System.Drawing.Font("Perpetua Titling MT", 12F);
            this.arquivoToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("arquivoToolStripMenuItem1.Image")));
            this.arquivoToolStripMenuItem1.Name = "arquivoToolStripMenuItem1";
            this.arquivoToolStripMenuItem1.Size = new System.Drawing.Size(188, 24);
            this.arquivoToolStripMenuItem1.Text = "Arquivo";
            this.arquivoToolStripMenuItem1.ToolTipText = "Arquivo";
            // 
            // fecharFormulárioToolStripMenuItem
            // 
            this.fecharFormulárioToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("fecharFormulárioToolStripMenuItem.Image")));
            this.fecharFormulárioToolStripMenuItem.Name = "fecharFormulárioToolStripMenuItem";
            this.fecharFormulárioToolStripMenuItem.Size = new System.Drawing.Size(250, 24);
            this.fecharFormulárioToolStripMenuItem.Text = "Fechar Formulário";
            this.fecharFormulárioToolStripMenuItem.ToolTipText = "Fechar o Formulário";
            // 
            // cadastroToolStripMenuItem1
            // 
            this.cadastroToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clienteEmpresaToolStripMenuItem1,
            this.candidatoToolStripMenuItem1,
            this.vagaToolStripMenuItem});
            this.cadastroToolStripMenuItem1.Font = new System.Drawing.Font("Perpetua Titling MT", 12F);
            this.cadastroToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("cadastroToolStripMenuItem1.Image")));
            this.cadastroToolStripMenuItem1.Name = "cadastroToolStripMenuItem1";
            this.cadastroToolStripMenuItem1.Size = new System.Drawing.Size(188, 24);
            this.cadastroToolStripMenuItem1.Text = "Cadastro";
            this.cadastroToolStripMenuItem1.ToolTipText = "Cadatro";
            // 
            // clienteEmpresaToolStripMenuItem1
            // 
            this.clienteEmpresaToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("clienteEmpresaToolStripMenuItem1.Image")));
            this.clienteEmpresaToolStripMenuItem1.Name = "clienteEmpresaToolStripMenuItem1";
            this.clienteEmpresaToolStripMenuItem1.Size = new System.Drawing.Size(224, 24);
            this.clienteEmpresaToolStripMenuItem1.Text = "Clientes Empresa";
            this.clienteEmpresaToolStripMenuItem1.ToolTipText = "Clientes Empresa";
            // 
            // candidatoToolStripMenuItem1
            // 
            this.candidatoToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("candidatoToolStripMenuItem1.Image")));
            this.candidatoToolStripMenuItem1.Name = "candidatoToolStripMenuItem1";
            this.candidatoToolStripMenuItem1.Size = new System.Drawing.Size(224, 24);
            this.candidatoToolStripMenuItem1.Text = "Candidatos";
            this.candidatoToolStripMenuItem1.ToolTipText = "Candidatos";
            // 
            // vagaToolStripMenuItem
            // 
            this.vagaToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("vagaToolStripMenuItem.Image")));
            this.vagaToolStripMenuItem.Name = "vagaToolStripMenuItem";
            this.vagaToolStripMenuItem.Size = new System.Drawing.Size(224, 24);
            this.vagaToolStripMenuItem.Text = "Vagas";
            this.vagaToolStripMenuItem.ToolTipText = "Vagas";
            // 
            // ferramentasToolStripMenuItem1
            // 
            this.ferramentasToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.calendáriToolStripMenuItem,
            this.calculadoraToolStripMenuItem1,
            this.windowsExplorerToolStripMenuItem1,
            this.iToolStripMenuItem1,
            this.editorDeTextoToolStripMenuItem1});
            this.ferramentasToolStripMenuItem1.Font = new System.Drawing.Font("Perpetua Titling MT", 12F);
            this.ferramentasToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("ferramentasToolStripMenuItem1.Image")));
            this.ferramentasToolStripMenuItem1.Name = "ferramentasToolStripMenuItem1";
            this.ferramentasToolStripMenuItem1.Size = new System.Drawing.Size(188, 24);
            this.ferramentasToolStripMenuItem1.Text = "Ferramentas";
            this.ferramentasToolStripMenuItem1.ToolTipText = "Ferramentas";
            // 
            // calendáriToolStripMenuItem
            // 
            this.calendáriToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("calendáriToolStripMenuItem.Image")));
            this.calendáriToolStripMenuItem.Name = "calendáriToolStripMenuItem";
            this.calendáriToolStripMenuItem.Size = new System.Drawing.Size(246, 24);
            this.calendáriToolStripMenuItem.Text = "Calendário";
            this.calendáriToolStripMenuItem.ToolTipText = "Calendário";
            // 
            // calculadoraToolStripMenuItem1
            // 
            this.calculadoraToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("calculadoraToolStripMenuItem1.Image")));
            this.calculadoraToolStripMenuItem1.Name = "calculadoraToolStripMenuItem1";
            this.calculadoraToolStripMenuItem1.Size = new System.Drawing.Size(246, 24);
            this.calculadoraToolStripMenuItem1.Text = "Calculadora";
            this.calculadoraToolStripMenuItem1.ToolTipText = "Calculadora";
            // 
            // windowsExplorerToolStripMenuItem1
            // 
            this.windowsExplorerToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("windowsExplorerToolStripMenuItem1.Image")));
            this.windowsExplorerToolStripMenuItem1.Name = "windowsExplorerToolStripMenuItem1";
            this.windowsExplorerToolStripMenuItem1.Size = new System.Drawing.Size(246, 24);
            this.windowsExplorerToolStripMenuItem1.Text = "Windows Explorer";
            this.windowsExplorerToolStripMenuItem1.ToolTipText = "Windows Explorer";
            // 
            // iToolStripMenuItem1
            // 
            this.iToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("iToolStripMenuItem1.Image")));
            this.iToolStripMenuItem1.Name = "iToolStripMenuItem1";
            this.iToolStripMenuItem1.Size = new System.Drawing.Size(246, 24);
            this.iToolStripMenuItem1.Text = "Internet Explorer";
            this.iToolStripMenuItem1.ToolTipText = "Internet Explorer";
            // 
            // editorDeTextoToolStripMenuItem1
            // 
            this.editorDeTextoToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("editorDeTextoToolStripMenuItem1.Image")));
            this.editorDeTextoToolStripMenuItem1.Name = "editorDeTextoToolStripMenuItem1";
            this.editorDeTextoToolStripMenuItem1.Size = new System.Drawing.Size(246, 24);
            this.editorDeTextoToolStripMenuItem1.Text = "Editor de Texto";
            this.editorDeTextoToolStripMenuItem1.ToolTipText = "Editor de Texto";
            // 
            // ajudaToolStripMenuItem1
            // 
            this.ajudaToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sobreOSistemaToolStripMenuItem1});
            this.ajudaToolStripMenuItem1.Font = new System.Drawing.Font("Perpetua Titling MT", 12F);
            this.ajudaToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("ajudaToolStripMenuItem1.Image")));
            this.ajudaToolStripMenuItem1.Name = "ajudaToolStripMenuItem1";
            this.ajudaToolStripMenuItem1.Size = new System.Drawing.Size(188, 24);
            this.ajudaToolStripMenuItem1.Text = "Ajuda";
            this.ajudaToolStripMenuItem1.ToolTipText = "Ajuda";
            // 
            // sobreOSistemaToolStripMenuItem1
            // 
            this.sobreOSistemaToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("sobreOSistemaToolStripMenuItem1.Image")));
            this.sobreOSistemaToolStripMenuItem1.Name = "sobreOSistemaToolStripMenuItem1";
            this.sobreOSistemaToolStripMenuItem1.Size = new System.Drawing.Size(221, 24);
            this.sobreOSistemaToolStripMenuItem1.Text = "Sobre o Sistema ";
            this.sobreOSistemaToolStripMenuItem1.ToolTipText = "Sobre o Sistema";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // FrmPrin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(755, 419);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmPrin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sistema 2ºBimestre- 3ºW";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem arquivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cadastroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clienteEmpresaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem candidatoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vagasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ferramentasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calendárioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calculadoraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem windowsExplorerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editorDeTextoToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ajudaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sobreOSistemaToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripMenuItem arquivoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem fecharFormulárioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cadastroToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem clienteEmpresaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem candidatoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem vagaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ferramentasToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem calendáriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calculadoraToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ajudaToolStripMenuItem1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolStripMenuItem windowsExplorerToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem iToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem editorDeTextoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sobreOSistemaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButton10;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;

    }
}