﻿namespace Industria_Metalurgica
{
    partial class FrmFunc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmFunc));
            System.Windows.Forms.Label nome_FuncLabel;
            System.Windows.Forms.Label sobrenome_FuncLabel;
            System.Windows.Forms.Label sexo_FuncLabel;
            System.Windows.Forms.Label idade_FuncLabel;
            System.Windows.Forms.Label filhos_FuncLabel;
            System.Windows.Forms.Label departamento_FuncLabel;
            System.Windows.Forms.Label rG_FuncLabel;
            System.Windows.Forms.Label cEP_FuncLabel;
            System.Windows.Forms.Label cidade_FuncLabel;
            System.Windows.Forms.Label est_FuncLabel;
            System.Windows.Forms.Label rua_FuncLabel;
            System.Windows.Forms.Label n__FuncLabel;
            System.Windows.Forms.Label bairro_FuncLabel;
            System.Windows.Forms.Label complemento_FuncLabel;
            System.Windows.Forms.Label telefone_FuncLabel;
            System.Windows.Forms.Label celular_FuncLabel;
            System.Windows.Forms.Label email_FuncLabel;
            System.Windows.Forms.Label dataAdm_FuncLabel;
            System.Windows.Forms.Label rendaFam_FuncLabel;
            System.Windows.Forms.Label salário_FuncLabel;
            System.Windows.Forms.Label taxaCom_FuncLabel;
            System.Windows.Forms.Label cPF_FuncLabel;
            this.funcionáriosBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.funcionáriosBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.funcionáriosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.industria_MetalurgicaDataSet = new Industria_Metalurgica.Industria_MetalurgicaDataSet();
            this.funcionáriosTableAdapter = new Industria_Metalurgica.Industria_MetalurgicaDataSetTableAdapters.FuncionáriosTableAdapter();
            this.tableAdapterManager = new Industria_Metalurgica.Industria_MetalurgicaDataSetTableAdapters.TableAdapterManager();
            this.button2 = new System.Windows.Forms.Button();
            this.nome_FuncTextBox = new System.Windows.Forms.TextBox();
            this.sobrenome_FuncTextBox = new System.Windows.Forms.TextBox();
            this.sexo_FuncComboBox = new System.Windows.Forms.ComboBox();
            this.idade_FuncTextBox = new System.Windows.Forms.TextBox();
            this.filhos_FuncTextBox = new System.Windows.Forms.TextBox();
            this.departamento_FuncComboBox = new System.Windows.Forms.ComboBox();
            this.rG_FuncMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.cEP_FuncMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.cidade_FuncTextBox = new System.Windows.Forms.TextBox();
            this.est_FuncComboBox = new System.Windows.Forms.ComboBox();
            this.rua_FuncTextBox = new System.Windows.Forms.TextBox();
            this.n__FuncTextBox = new System.Windows.Forms.TextBox();
            this.bairro_FuncTextBox = new System.Windows.Forms.TextBox();
            this.complemento_FuncTextBox = new System.Windows.Forms.TextBox();
            this.telefone_FuncMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.celular_FuncMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.email_FuncTextBox = new System.Windows.Forms.TextBox();
            this.dataAdm_FuncDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.rendaFam_FuncMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.salário_FuncMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.taxaCom_FuncMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.cPF_FuncTextBox = new System.Windows.Forms.TextBox();
            nome_FuncLabel = new System.Windows.Forms.Label();
            sobrenome_FuncLabel = new System.Windows.Forms.Label();
            sexo_FuncLabel = new System.Windows.Forms.Label();
            idade_FuncLabel = new System.Windows.Forms.Label();
            filhos_FuncLabel = new System.Windows.Forms.Label();
            departamento_FuncLabel = new System.Windows.Forms.Label();
            rG_FuncLabel = new System.Windows.Forms.Label();
            cEP_FuncLabel = new System.Windows.Forms.Label();
            cidade_FuncLabel = new System.Windows.Forms.Label();
            est_FuncLabel = new System.Windows.Forms.Label();
            rua_FuncLabel = new System.Windows.Forms.Label();
            n__FuncLabel = new System.Windows.Forms.Label();
            bairro_FuncLabel = new System.Windows.Forms.Label();
            complemento_FuncLabel = new System.Windows.Forms.Label();
            telefone_FuncLabel = new System.Windows.Forms.Label();
            celular_FuncLabel = new System.Windows.Forms.Label();
            email_FuncLabel = new System.Windows.Forms.Label();
            dataAdm_FuncLabel = new System.Windows.Forms.Label();
            rendaFam_FuncLabel = new System.Windows.Forms.Label();
            salário_FuncLabel = new System.Windows.Forms.Label();
            taxaCom_FuncLabel = new System.Windows.Forms.Label();
            cPF_FuncLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.funcionáriosBindingNavigator)).BeginInit();
            this.funcionáriosBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.funcionáriosBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.industria_MetalurgicaDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // funcionáriosBindingNavigator
            // 
            this.funcionáriosBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.funcionáriosBindingNavigator.BindingSource = this.funcionáriosBindingSource;
            this.funcionáriosBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.funcionáriosBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.funcionáriosBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.funcionáriosBindingNavigatorSaveItem});
            this.funcionáriosBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.funcionáriosBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.funcionáriosBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.funcionáriosBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.funcionáriosBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.funcionáriosBindingNavigator.Name = "funcionáriosBindingNavigator";
            this.funcionáriosBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.funcionáriosBindingNavigator.Size = new System.Drawing.Size(466, 25);
            this.funcionáriosBindingNavigator.TabIndex = 0;
            this.funcionáriosBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // funcionáriosBindingNavigatorSaveItem
            // 
            this.funcionáriosBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.funcionáriosBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("funcionáriosBindingNavigatorSaveItem.Image")));
            this.funcionáriosBindingNavigatorSaveItem.Name = "funcionáriosBindingNavigatorSaveItem";
            this.funcionáriosBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.funcionáriosBindingNavigatorSaveItem.Text = "Save Data";
            this.funcionáriosBindingNavigatorSaveItem.Click += new System.EventHandler(this.funcionáriosBindingNavigatorSaveItem_Click);
            // 
            // funcionáriosBindingSource
            // 
            this.funcionáriosBindingSource.DataMember = "Funcionários";
            this.funcionáriosBindingSource.DataSource = this.industria_MetalurgicaDataSet;
            // 
            // industria_MetalurgicaDataSet
            // 
            this.industria_MetalurgicaDataSet.DataSetName = "Industria_MetalurgicaDataSet";
            this.industria_MetalurgicaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // funcionáriosTableAdapter
            // 
            this.funcionáriosTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ClientesTableAdapter = null;
            this.tableAdapterManager.ComprasTableAdapter = null;
            this.tableAdapterManager.ContasTableAdapter = null;
            this.tableAdapterManager.FornecedoresTableAdapter = null;
            this.tableAdapterManager.FuncionáriosTableAdapter = this.funcionáriosTableAdapter;
            this.tableAdapterManager.LoginTableAdapter = null;
            this.tableAdapterManager.Nota_fiscalTableAdapter = null;
            this.tableAdapterManager.ProdutosTableAdapter = null;
            this.tableAdapterManager.TransportadorasTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Industria_Metalurgica.Industria_MetalurgicaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VendasTableAdapter = null;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Lucida Sans", 11.25F);
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(342, 646);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(88, 30);
            this.button2.TabIndex = 43;
            this.button2.Text = "&Fechar";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // nome_FuncLabel
            // 
            nome_FuncLabel.AutoSize = true;
            nome_FuncLabel.BackColor = System.Drawing.Color.Transparent;
            nome_FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            nome_FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            nome_FuncLabel.Location = new System.Drawing.Point(31, 49);
            nome_FuncLabel.Name = "nome_FuncLabel";
            nome_FuncLabel.Size = new System.Drawing.Size(75, 30);
            nome_FuncLabel.TabIndex = 43;
            nome_FuncLabel.Text = "Nome:";
            // 
            // nome_FuncTextBox
            // 
            this.nome_FuncTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.funcionáriosBindingSource, "Nome_Func", true));
            this.nome_FuncTextBox.Location = new System.Drawing.Point(230, 49);
            this.nome_FuncTextBox.Name = "nome_FuncTextBox";
            this.nome_FuncTextBox.Size = new System.Drawing.Size(200, 20);
            this.nome_FuncTextBox.TabIndex = 44;
            this.nome_FuncTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // sobrenome_FuncLabel
            // 
            sobrenome_FuncLabel.AutoSize = true;
            sobrenome_FuncLabel.BackColor = System.Drawing.Color.Transparent;
            sobrenome_FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            sobrenome_FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            sobrenome_FuncLabel.Location = new System.Drawing.Point(31, 75);
            sobrenome_FuncLabel.Name = "sobrenome_FuncLabel";
            sobrenome_FuncLabel.Size = new System.Drawing.Size(124, 30);
            sobrenome_FuncLabel.TabIndex = 45;
            sobrenome_FuncLabel.Text = "Sobrenome:";
            // 
            // sobrenome_FuncTextBox
            // 
            this.sobrenome_FuncTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.funcionáriosBindingSource, "Sobrenome_Func", true));
            this.sobrenome_FuncTextBox.Location = new System.Drawing.Point(230, 75);
            this.sobrenome_FuncTextBox.Name = "sobrenome_FuncTextBox";
            this.sobrenome_FuncTextBox.Size = new System.Drawing.Size(200, 20);
            this.sobrenome_FuncTextBox.TabIndex = 46;
            this.sobrenome_FuncTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // sexo_FuncLabel
            // 
            sexo_FuncLabel.AutoSize = true;
            sexo_FuncLabel.BackColor = System.Drawing.Color.Transparent;
            sexo_FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            sexo_FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            sexo_FuncLabel.Location = new System.Drawing.Point(31, 101);
            sexo_FuncLabel.Name = "sexo_FuncLabel";
            sexo_FuncLabel.Size = new System.Drawing.Size(62, 30);
            sexo_FuncLabel.TabIndex = 47;
            sexo_FuncLabel.Text = "Sexo:";
            // 
            // sexo_FuncComboBox
            // 
            this.sexo_FuncComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.funcionáriosBindingSource, "Sexo_Func", true));
            this.sexo_FuncComboBox.FormattingEnabled = true;
            this.sexo_FuncComboBox.Items.AddRange(new object[] {
            "Feminino",
            "Masculino",
            "Outro"});
            this.sexo_FuncComboBox.Location = new System.Drawing.Point(230, 101);
            this.sexo_FuncComboBox.Name = "sexo_FuncComboBox";
            this.sexo_FuncComboBox.Size = new System.Drawing.Size(200, 21);
            this.sexo_FuncComboBox.TabIndex = 48;
            // 
            // idade_FuncLabel
            // 
            idade_FuncLabel.AutoSize = true;
            idade_FuncLabel.BackColor = System.Drawing.Color.Transparent;
            idade_FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            idade_FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            idade_FuncLabel.Location = new System.Drawing.Point(31, 128);
            idade_FuncLabel.Name = "idade_FuncLabel";
            idade_FuncLabel.Size = new System.Drawing.Size(70, 30);
            idade_FuncLabel.TabIndex = 49;
            idade_FuncLabel.Text = "Idade:";
            // 
            // idade_FuncTextBox
            // 
            this.idade_FuncTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.funcionáriosBindingSource, "Idade_Func", true));
            this.idade_FuncTextBox.Location = new System.Drawing.Point(230, 128);
            this.idade_FuncTextBox.Name = "idade_FuncTextBox";
            this.idade_FuncTextBox.Size = new System.Drawing.Size(200, 20);
            this.idade_FuncTextBox.TabIndex = 50;
            this.idade_FuncTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // filhos_FuncLabel
            // 
            filhos_FuncLabel.AutoSize = true;
            filhos_FuncLabel.BackColor = System.Drawing.Color.Transparent;
            filhos_FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            filhos_FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            filhos_FuncLabel.Location = new System.Drawing.Point(31, 154);
            filhos_FuncLabel.Name = "filhos_FuncLabel";
            filhos_FuncLabel.Size = new System.Drawing.Size(71, 30);
            filhos_FuncLabel.TabIndex = 51;
            filhos_FuncLabel.Text = "Filhos:";
            // 
            // filhos_FuncTextBox
            // 
            this.filhos_FuncTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.funcionáriosBindingSource, "Filhos_Func", true));
            this.filhos_FuncTextBox.Location = new System.Drawing.Point(230, 154);
            this.filhos_FuncTextBox.Name = "filhos_FuncTextBox";
            this.filhos_FuncTextBox.Size = new System.Drawing.Size(200, 20);
            this.filhos_FuncTextBox.TabIndex = 52;
            this.filhos_FuncTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // departamento_FuncLabel
            // 
            departamento_FuncLabel.AutoSize = true;
            departamento_FuncLabel.BackColor = System.Drawing.Color.Transparent;
            departamento_FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            departamento_FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            departamento_FuncLabel.Location = new System.Drawing.Point(31, 180);
            departamento_FuncLabel.Name = "departamento_FuncLabel";
            departamento_FuncLabel.Size = new System.Drawing.Size(152, 30);
            departamento_FuncLabel.TabIndex = 53;
            departamento_FuncLabel.Text = "Departamento:";
            // 
            // departamento_FuncComboBox
            // 
            this.departamento_FuncComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.funcionáriosBindingSource, "Departamento_Func", true));
            this.departamento_FuncComboBox.FormattingEnabled = true;
            this.departamento_FuncComboBox.Location = new System.Drawing.Point(230, 180);
            this.departamento_FuncComboBox.Name = "departamento_FuncComboBox";
            this.departamento_FuncComboBox.Size = new System.Drawing.Size(200, 21);
            this.departamento_FuncComboBox.TabIndex = 54;
            // 
            // rG_FuncLabel
            // 
            rG_FuncLabel.AutoSize = true;
            rG_FuncLabel.BackColor = System.Drawing.Color.Transparent;
            rG_FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            rG_FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            rG_FuncLabel.Location = new System.Drawing.Point(31, 207);
            rG_FuncLabel.Name = "rG_FuncLabel";
            rG_FuncLabel.Size = new System.Drawing.Size(45, 30);
            rG_FuncLabel.TabIndex = 55;
            rG_FuncLabel.Text = "RG:";
            // 
            // rG_FuncMaskedTextBox
            // 
            this.rG_FuncMaskedTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.funcionáriosBindingSource, "RG_Func", true));
            this.rG_FuncMaskedTextBox.Location = new System.Drawing.Point(230, 207);
            this.rG_FuncMaskedTextBox.Mask = "00,000,0000-0";
            this.rG_FuncMaskedTextBox.Name = "rG_FuncMaskedTextBox";
            this.rG_FuncMaskedTextBox.Size = new System.Drawing.Size(200, 20);
            this.rG_FuncMaskedTextBox.TabIndex = 56;
            this.rG_FuncMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cEP_FuncLabel
            // 
            cEP_FuncLabel.AutoSize = true;
            cEP_FuncLabel.BackColor = System.Drawing.Color.Transparent;
            cEP_FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            cEP_FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            cEP_FuncLabel.Location = new System.Drawing.Point(31, 233);
            cEP_FuncLabel.Name = "cEP_FuncLabel";
            cEP_FuncLabel.Size = new System.Drawing.Size(54, 30);
            cEP_FuncLabel.TabIndex = 57;
            cEP_FuncLabel.Text = "CEP:";
            // 
            // cEP_FuncMaskedTextBox
            // 
            this.cEP_FuncMaskedTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.funcionáriosBindingSource, "CEP_Func", true));
            this.cEP_FuncMaskedTextBox.Location = new System.Drawing.Point(230, 233);
            this.cEP_FuncMaskedTextBox.Mask = "00,000-000 ";
            this.cEP_FuncMaskedTextBox.Name = "cEP_FuncMaskedTextBox";
            this.cEP_FuncMaskedTextBox.Size = new System.Drawing.Size(200, 20);
            this.cEP_FuncMaskedTextBox.TabIndex = 58;
            this.cEP_FuncMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cidade_FuncLabel
            // 
            cidade_FuncLabel.AutoSize = true;
            cidade_FuncLabel.BackColor = System.Drawing.Color.Transparent;
            cidade_FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            cidade_FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            cidade_FuncLabel.Location = new System.Drawing.Point(31, 259);
            cidade_FuncLabel.Name = "cidade_FuncLabel";
            cidade_FuncLabel.Size = new System.Drawing.Size(82, 30);
            cidade_FuncLabel.TabIndex = 59;
            cidade_FuncLabel.Text = "Cidade:";
            // 
            // cidade_FuncTextBox
            // 
            this.cidade_FuncTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.funcionáriosBindingSource, "Cidade_Func", true));
            this.cidade_FuncTextBox.Location = new System.Drawing.Point(230, 259);
            this.cidade_FuncTextBox.Name = "cidade_FuncTextBox";
            this.cidade_FuncTextBox.Size = new System.Drawing.Size(200, 20);
            this.cidade_FuncTextBox.TabIndex = 60;
            this.cidade_FuncTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // est_FuncLabel
            // 
            est_FuncLabel.AutoSize = true;
            est_FuncLabel.BackColor = System.Drawing.Color.Transparent;
            est_FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            est_FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            est_FuncLabel.Location = new System.Drawing.Point(31, 285);
            est_FuncLabel.Name = "est_FuncLabel";
            est_FuncLabel.Size = new System.Drawing.Size(80, 30);
            est_FuncLabel.TabIndex = 61;
            est_FuncLabel.Text = "Estado:";
            // 
            // est_FuncComboBox
            // 
            this.est_FuncComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.funcionáriosBindingSource, "Est_Func", true));
            this.est_FuncComboBox.FormattingEnabled = true;
            this.est_FuncComboBox.Items.AddRange(new object[] {
            "Acre",
            "Alagoas",
            "Amapá",
            "Amazonas",
            "Bahia",
            "Ceará",
            "Distrito Federal",
            "Espírito Santos",
            "Goiás",
            "Maranhão",
            "Mato Grosso",
            "Mato Grosso do Sul\t",
            "Minas Gerais",
            "Pará",
            "Paraíba",
            "Paraná",
            "Pernambuco",
            "Piauí",
            "Rio de Janeiro",
            "Rio Grande do Norte",
            "Rio Grande do Sul",
            "Rondônia",
            "Roraima",
            "Santa Catarina\t\t",
            "São Paulo",
            "Sergipe",
            "Tocantins"});
            this.est_FuncComboBox.Location = new System.Drawing.Point(230, 285);
            this.est_FuncComboBox.Name = "est_FuncComboBox";
            this.est_FuncComboBox.Size = new System.Drawing.Size(200, 21);
            this.est_FuncComboBox.TabIndex = 62;
            // 
            // rua_FuncLabel
            // 
            rua_FuncLabel.AutoSize = true;
            rua_FuncLabel.BackColor = System.Drawing.Color.Transparent;
            rua_FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            rua_FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            rua_FuncLabel.Location = new System.Drawing.Point(31, 312);
            rua_FuncLabel.Name = "rua_FuncLabel";
            rua_FuncLabel.Size = new System.Drawing.Size(54, 30);
            rua_FuncLabel.TabIndex = 63;
            rua_FuncLabel.Text = "Rua:";
            // 
            // rua_FuncTextBox
            // 
            this.rua_FuncTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.funcionáriosBindingSource, "Rua_Func", true));
            this.rua_FuncTextBox.Location = new System.Drawing.Point(230, 312);
            this.rua_FuncTextBox.Name = "rua_FuncTextBox";
            this.rua_FuncTextBox.Size = new System.Drawing.Size(200, 20);
            this.rua_FuncTextBox.TabIndex = 64;
            this.rua_FuncTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // n__FuncLabel
            // 
            n__FuncLabel.AutoSize = true;
            n__FuncLabel.BackColor = System.Drawing.Color.Transparent;
            n__FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            n__FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            n__FuncLabel.Location = new System.Drawing.Point(31, 338);
            n__FuncLabel.Name = "n__FuncLabel";
            n__FuncLabel.Size = new System.Drawing.Size(42, 30);
            n__FuncLabel.TabIndex = 65;
            n__FuncLabel.Text = "N°:";
            // 
            // n__FuncTextBox
            // 
            this.n__FuncTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.funcionáriosBindingSource, "N°_Func", true));
            this.n__FuncTextBox.Location = new System.Drawing.Point(230, 338);
            this.n__FuncTextBox.Name = "n__FuncTextBox";
            this.n__FuncTextBox.Size = new System.Drawing.Size(200, 20);
            this.n__FuncTextBox.TabIndex = 66;
            this.n__FuncTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bairro_FuncLabel
            // 
            bairro_FuncLabel.AutoSize = true;
            bairro_FuncLabel.BackColor = System.Drawing.Color.Transparent;
            bairro_FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            bairro_FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            bairro_FuncLabel.Location = new System.Drawing.Point(31, 364);
            bairro_FuncLabel.Name = "bairro_FuncLabel";
            bairro_FuncLabel.Size = new System.Drawing.Size(72, 30);
            bairro_FuncLabel.TabIndex = 67;
            bairro_FuncLabel.Text = "Bairro:";
            // 
            // bairro_FuncTextBox
            // 
            this.bairro_FuncTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.funcionáriosBindingSource, "Bairro_Func", true));
            this.bairro_FuncTextBox.Location = new System.Drawing.Point(230, 364);
            this.bairro_FuncTextBox.Name = "bairro_FuncTextBox";
            this.bairro_FuncTextBox.Size = new System.Drawing.Size(200, 20);
            this.bairro_FuncTextBox.TabIndex = 68;
            this.bairro_FuncTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // complemento_FuncLabel
            // 
            complemento_FuncLabel.AutoSize = true;
            complemento_FuncLabel.BackColor = System.Drawing.Color.Transparent;
            complemento_FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            complemento_FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            complemento_FuncLabel.Location = new System.Drawing.Point(31, 390);
            complemento_FuncLabel.Name = "complemento_FuncLabel";
            complemento_FuncLabel.Size = new System.Drawing.Size(149, 30);
            complemento_FuncLabel.TabIndex = 69;
            complemento_FuncLabel.Text = "Complemento:";
            // 
            // complemento_FuncTextBox
            // 
            this.complemento_FuncTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.funcionáriosBindingSource, "Complemento_Func", true));
            this.complemento_FuncTextBox.Location = new System.Drawing.Point(230, 390);
            this.complemento_FuncTextBox.Name = "complemento_FuncTextBox";
            this.complemento_FuncTextBox.Size = new System.Drawing.Size(200, 20);
            this.complemento_FuncTextBox.TabIndex = 70;
            this.complemento_FuncTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // telefone_FuncLabel
            // 
            telefone_FuncLabel.AutoSize = true;
            telefone_FuncLabel.BackColor = System.Drawing.Color.Transparent;
            telefone_FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            telefone_FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            telefone_FuncLabel.Location = new System.Drawing.Point(31, 416);
            telefone_FuncLabel.Name = "telefone_FuncLabel";
            telefone_FuncLabel.Size = new System.Drawing.Size(96, 30);
            telefone_FuncLabel.TabIndex = 71;
            telefone_FuncLabel.Text = "Telefone:";
            // 
            // telefone_FuncMaskedTextBox
            // 
            this.telefone_FuncMaskedTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.funcionáriosBindingSource, "Telefone_Func", true));
            this.telefone_FuncMaskedTextBox.Location = new System.Drawing.Point(230, 416);
            this.telefone_FuncMaskedTextBox.Mask = "(99) 0000-0000";
            this.telefone_FuncMaskedTextBox.Name = "telefone_FuncMaskedTextBox";
            this.telefone_FuncMaskedTextBox.Size = new System.Drawing.Size(200, 20);
            this.telefone_FuncMaskedTextBox.TabIndex = 72;
            this.telefone_FuncMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // celular_FuncLabel
            // 
            celular_FuncLabel.AutoSize = true;
            celular_FuncLabel.BackColor = System.Drawing.Color.Transparent;
            celular_FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            celular_FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            celular_FuncLabel.Location = new System.Drawing.Point(31, 442);
            celular_FuncLabel.Name = "celular_FuncLabel";
            celular_FuncLabel.Size = new System.Drawing.Size(82, 30);
            celular_FuncLabel.TabIndex = 73;
            celular_FuncLabel.Text = "Celular:";
            // 
            // celular_FuncMaskedTextBox
            // 
            this.celular_FuncMaskedTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.funcionáriosBindingSource, "Celular_Func", true));
            this.celular_FuncMaskedTextBox.Location = new System.Drawing.Point(230, 442);
            this.celular_FuncMaskedTextBox.Mask = "(99) 00000-0000";
            this.celular_FuncMaskedTextBox.Name = "celular_FuncMaskedTextBox";
            this.celular_FuncMaskedTextBox.Size = new System.Drawing.Size(200, 20);
            this.celular_FuncMaskedTextBox.TabIndex = 74;
            this.celular_FuncMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // email_FuncLabel
            // 
            email_FuncLabel.AutoSize = true;
            email_FuncLabel.BackColor = System.Drawing.Color.Transparent;
            email_FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            email_FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            email_FuncLabel.Location = new System.Drawing.Point(31, 468);
            email_FuncLabel.Name = "email_FuncLabel";
            email_FuncLabel.Size = new System.Drawing.Size(68, 30);
            email_FuncLabel.TabIndex = 75;
            email_FuncLabel.Text = "Email:";
            // 
            // email_FuncTextBox
            // 
            this.email_FuncTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.funcionáriosBindingSource, "Email_Func", true));
            this.email_FuncTextBox.Location = new System.Drawing.Point(230, 468);
            this.email_FuncTextBox.Name = "email_FuncTextBox";
            this.email_FuncTextBox.Size = new System.Drawing.Size(200, 20);
            this.email_FuncTextBox.TabIndex = 76;
            this.email_FuncTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dataAdm_FuncLabel
            // 
            dataAdm_FuncLabel.AutoSize = true;
            dataAdm_FuncLabel.BackColor = System.Drawing.Color.Transparent;
            dataAdm_FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            dataAdm_FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            dataAdm_FuncLabel.Location = new System.Drawing.Point(31, 495);
            dataAdm_FuncLabel.Name = "dataAdm_FuncLabel";
            dataAdm_FuncLabel.Size = new System.Drawing.Size(158, 30);
            dataAdm_FuncLabel.TabIndex = 77;
            dataAdm_FuncLabel.Text = "Data Admissão:";
            // 
            // dataAdm_FuncDateTimePicker
            // 
            this.dataAdm_FuncDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.funcionáriosBindingSource, "DataAdm_Func", true));
            this.dataAdm_FuncDateTimePicker.Location = new System.Drawing.Point(230, 494);
            this.dataAdm_FuncDateTimePicker.Name = "dataAdm_FuncDateTimePicker";
            this.dataAdm_FuncDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.dataAdm_FuncDateTimePicker.TabIndex = 78;
            // 
            // rendaFam_FuncLabel
            // 
            rendaFam_FuncLabel.AutoSize = true;
            rendaFam_FuncLabel.BackColor = System.Drawing.Color.Transparent;
            rendaFam_FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            rendaFam_FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            rendaFam_FuncLabel.Location = new System.Drawing.Point(31, 520);
            rendaFam_FuncLabel.Name = "rendaFam_FuncLabel";
            rendaFam_FuncLabel.Size = new System.Drawing.Size(76, 30);
            rendaFam_FuncLabel.TabIndex = 79;
            rendaFam_FuncLabel.Text = "Renda:";
            // 
            // rendaFam_FuncMaskedTextBox
            // 
            this.rendaFam_FuncMaskedTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.funcionáriosBindingSource, "RendaFam_Func", true));
            this.rendaFam_FuncMaskedTextBox.Location = new System.Drawing.Point(230, 520);
            this.rendaFam_FuncMaskedTextBox.Name = "rendaFam_FuncMaskedTextBox";
            this.rendaFam_FuncMaskedTextBox.Size = new System.Drawing.Size(200, 20);
            this.rendaFam_FuncMaskedTextBox.TabIndex = 80;
            this.rendaFam_FuncMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // salário_FuncLabel
            // 
            salário_FuncLabel.AutoSize = true;
            salário_FuncLabel.BackColor = System.Drawing.Color.Transparent;
            salário_FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            salário_FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            salário_FuncLabel.Location = new System.Drawing.Point(31, 546);
            salário_FuncLabel.Name = "salário_FuncLabel";
            salário_FuncLabel.Size = new System.Drawing.Size(80, 30);
            salário_FuncLabel.TabIndex = 81;
            salário_FuncLabel.Text = "Salário:";
            // 
            // salário_FuncMaskedTextBox
            // 
            this.salário_FuncMaskedTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.funcionáriosBindingSource, "Salário_Func", true));
            this.salário_FuncMaskedTextBox.Location = new System.Drawing.Point(230, 546);
            this.salário_FuncMaskedTextBox.Name = "salário_FuncMaskedTextBox";
            this.salário_FuncMaskedTextBox.Size = new System.Drawing.Size(200, 20);
            this.salário_FuncMaskedTextBox.TabIndex = 82;
            this.salário_FuncMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // taxaCom_FuncLabel
            // 
            taxaCom_FuncLabel.AutoSize = true;
            taxaCom_FuncLabel.BackColor = System.Drawing.Color.Transparent;
            taxaCom_FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            taxaCom_FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            taxaCom_FuncLabel.Location = new System.Drawing.Point(31, 572);
            taxaCom_FuncLabel.Name = "taxaCom_FuncLabel";
            taxaCom_FuncLabel.Size = new System.Drawing.Size(154, 30);
            taxaCom_FuncLabel.TabIndex = 83;
            taxaCom_FuncLabel.Text = "Taxa Comissão:";
            // 
            // taxaCom_FuncMaskedTextBox
            // 
            this.taxaCom_FuncMaskedTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.funcionáriosBindingSource, "TaxaCom_Func", true));
            this.taxaCom_FuncMaskedTextBox.Location = new System.Drawing.Point(230, 572);
            this.taxaCom_FuncMaskedTextBox.Name = "taxaCom_FuncMaskedTextBox";
            this.taxaCom_FuncMaskedTextBox.Size = new System.Drawing.Size(200, 20);
            this.taxaCom_FuncMaskedTextBox.TabIndex = 84;
            this.taxaCom_FuncMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cPF_FuncLabel
            // 
            cPF_FuncLabel.AutoSize = true;
            cPF_FuncLabel.BackColor = System.Drawing.Color.Transparent;
            cPF_FuncLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            cPF_FuncLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            cPF_FuncLabel.Location = new System.Drawing.Point(31, 598);
            cPF_FuncLabel.Name = "cPF_FuncLabel";
            cPF_FuncLabel.Size = new System.Drawing.Size(53, 30);
            cPF_FuncLabel.TabIndex = 85;
            cPF_FuncLabel.Text = "CPF:";
            // 
            // cPF_FuncTextBox
            // 
            this.cPF_FuncTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.funcionáriosBindingSource, "CPF_Func", true));
            this.cPF_FuncTextBox.Location = new System.Drawing.Point(230, 598);
            this.cPF_FuncTextBox.Name = "cPF_FuncTextBox";
            this.cPF_FuncTextBox.Size = new System.Drawing.Size(200, 20);
            this.cPF_FuncTextBox.TabIndex = 86;
            this.cPF_FuncTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // FrmFunc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(466, 701);
            this.Controls.Add(nome_FuncLabel);
            this.Controls.Add(this.nome_FuncTextBox);
            this.Controls.Add(sobrenome_FuncLabel);
            this.Controls.Add(this.sobrenome_FuncTextBox);
            this.Controls.Add(sexo_FuncLabel);
            this.Controls.Add(this.sexo_FuncComboBox);
            this.Controls.Add(idade_FuncLabel);
            this.Controls.Add(this.idade_FuncTextBox);
            this.Controls.Add(filhos_FuncLabel);
            this.Controls.Add(this.filhos_FuncTextBox);
            this.Controls.Add(departamento_FuncLabel);
            this.Controls.Add(this.departamento_FuncComboBox);
            this.Controls.Add(rG_FuncLabel);
            this.Controls.Add(this.rG_FuncMaskedTextBox);
            this.Controls.Add(cEP_FuncLabel);
            this.Controls.Add(this.cEP_FuncMaskedTextBox);
            this.Controls.Add(cidade_FuncLabel);
            this.Controls.Add(this.cidade_FuncTextBox);
            this.Controls.Add(est_FuncLabel);
            this.Controls.Add(this.est_FuncComboBox);
            this.Controls.Add(rua_FuncLabel);
            this.Controls.Add(this.rua_FuncTextBox);
            this.Controls.Add(n__FuncLabel);
            this.Controls.Add(this.n__FuncTextBox);
            this.Controls.Add(bairro_FuncLabel);
            this.Controls.Add(this.bairro_FuncTextBox);
            this.Controls.Add(complemento_FuncLabel);
            this.Controls.Add(this.complemento_FuncTextBox);
            this.Controls.Add(telefone_FuncLabel);
            this.Controls.Add(this.telefone_FuncMaskedTextBox);
            this.Controls.Add(celular_FuncLabel);
            this.Controls.Add(this.celular_FuncMaskedTextBox);
            this.Controls.Add(email_FuncLabel);
            this.Controls.Add(this.email_FuncTextBox);
            this.Controls.Add(dataAdm_FuncLabel);
            this.Controls.Add(this.dataAdm_FuncDateTimePicker);
            this.Controls.Add(rendaFam_FuncLabel);
            this.Controls.Add(this.rendaFam_FuncMaskedTextBox);
            this.Controls.Add(salário_FuncLabel);
            this.Controls.Add(this.salário_FuncMaskedTextBox);
            this.Controls.Add(taxaCom_FuncLabel);
            this.Controls.Add(this.taxaCom_FuncMaskedTextBox);
            this.Controls.Add(cPF_FuncLabel);
            this.Controls.Add(this.cPF_FuncTextBox);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.funcionáriosBindingNavigator);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmFunc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Funcionários";
            this.Load += new System.EventHandler(this.FrmFunc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.funcionáriosBindingNavigator)).EndInit();
            this.funcionáriosBindingNavigator.ResumeLayout(false);
            this.funcionáriosBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.funcionáriosBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.industria_MetalurgicaDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Industria_MetalurgicaDataSet industria_MetalurgicaDataSet;
        private System.Windows.Forms.BindingSource funcionáriosBindingSource;
        private Industria_Metalurgica.Industria_MetalurgicaDataSetTableAdapters.FuncionáriosTableAdapter funcionáriosTableAdapter;
        private Industria_Metalurgica.Industria_MetalurgicaDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator funcionáriosBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton funcionáriosBindingNavigatorSaveItem;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox nome_FuncTextBox;
        private System.Windows.Forms.TextBox sobrenome_FuncTextBox;
        private System.Windows.Forms.ComboBox sexo_FuncComboBox;
        private System.Windows.Forms.TextBox idade_FuncTextBox;
        private System.Windows.Forms.TextBox filhos_FuncTextBox;
        private System.Windows.Forms.ComboBox departamento_FuncComboBox;
        private System.Windows.Forms.MaskedTextBox rG_FuncMaskedTextBox;
        private System.Windows.Forms.MaskedTextBox cEP_FuncMaskedTextBox;
        private System.Windows.Forms.TextBox cidade_FuncTextBox;
        private System.Windows.Forms.ComboBox est_FuncComboBox;
        private System.Windows.Forms.TextBox rua_FuncTextBox;
        private System.Windows.Forms.TextBox n__FuncTextBox;
        private System.Windows.Forms.TextBox bairro_FuncTextBox;
        private System.Windows.Forms.TextBox complemento_FuncTextBox;
        private System.Windows.Forms.MaskedTextBox telefone_FuncMaskedTextBox;
        private System.Windows.Forms.MaskedTextBox celular_FuncMaskedTextBox;
        private System.Windows.Forms.TextBox email_FuncTextBox;
        private System.Windows.Forms.DateTimePicker dataAdm_FuncDateTimePicker;
        private System.Windows.Forms.MaskedTextBox rendaFam_FuncMaskedTextBox;
        private System.Windows.Forms.MaskedTextBox salário_FuncMaskedTextBox;
        private System.Windows.Forms.MaskedTextBox taxaCom_FuncMaskedTextBox;
        private System.Windows.Forms.TextBox cPF_FuncTextBox;
    }
}