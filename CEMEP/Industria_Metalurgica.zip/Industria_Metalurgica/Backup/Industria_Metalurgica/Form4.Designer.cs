﻿namespace Industria_Metalurgica
{
    partial class FrmPrinc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPrinc));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.arquivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Contas = new System.Windows.Forms.ToolStripMenuItem();
            this.Compras = new System.Windows.Forms.ToolStripMenuItem();
            this.Clientes = new System.Windows.Forms.ToolStripMenuItem();
            this.Fornecedores = new System.Windows.Forms.ToolStripMenuItem();
            this.Funcionarios = new System.Windows.Forms.ToolStripMenuItem();
            this.NotaFiscal = new System.Windows.Forms.ToolStripMenuItem();
            this.Produtos = new System.Windows.Forms.ToolStripMenuItem();
            this.Transportadoras = new System.Windows.Forms.ToolStripMenuItem();
            this.Vendas = new System.Windows.Forms.ToolStripMenuItem();
            this.consultasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contasToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.comprasToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.clientesToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.fornecedoresToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.funcionáriosToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.notaFiscalToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.produtosToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.transportadorasToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.vendasToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ferramentasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calendárioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calculadoraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.windowsExplorerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editorDeTextoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ajudaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sobreOSistemaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton11 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton12 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton13 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton14 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton15 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton16 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton10 = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.arquivoToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.fecharOSistemaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastroToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.contasToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.comprasToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.clientesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.fornecedoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funcionáriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notaFiscalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.produtosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.transportadorasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vendasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultasToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.contasToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.comprasToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.clientesToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.fornecedoresToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.funcionáriosToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.notaFiscalToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.produtosToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.transportadoraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vendToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ferramentasToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.calendárioToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.calculadoraToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.windowsExplorerToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.internetExplorerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.editorDeTextoToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ajudaToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.sobreOSistemaToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.arquivoToolStripMenuItem,
            this.cadastroToolStripMenuItem,
            this.consultasToolStripMenuItem,
            this.ferramentasToolStripMenuItem,
            this.ajudaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(675, 27);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // arquivoToolStripMenuItem
            // 
            this.arquivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sairToolStripMenuItem});
            this.arquivoToolStripMenuItem.Font = new System.Drawing.Font("Perpetua Titling MT", 12F);
            this.arquivoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("arquivoToolStripMenuItem.Image")));
            this.arquivoToolStripMenuItem.Name = "arquivoToolStripMenuItem";
            this.arquivoToolStripMenuItem.Size = new System.Drawing.Size(114, 23);
            this.arquivoToolStripMenuItem.Text = "Arquivo";
            this.arquivoToolStripMenuItem.ToolTipText = "Arquivo";
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("sairToolStripMenuItem.Image")));
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F)));
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(276, 24);
            this.sairToolStripMenuItem.Text = "Fechar Sistema";
            this.sairToolStripMenuItem.ToolTipText = "Fechar Sistema";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // cadastroToolStripMenuItem
            // 
            this.cadastroToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Contas,
            this.Compras,
            this.Clientes,
            this.Fornecedores,
            this.Funcionarios,
            this.NotaFiscal,
            this.Produtos,
            this.Transportadoras,
            this.Vendas});
            this.cadastroToolStripMenuItem.Font = new System.Drawing.Font("Perpetua Titling MT", 12F);
            this.cadastroToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("cadastroToolStripMenuItem.Image")));
            this.cadastroToolStripMenuItem.Name = "cadastroToolStripMenuItem";
            this.cadastroToolStripMenuItem.Size = new System.Drawing.Size(126, 23);
            this.cadastroToolStripMenuItem.Text = "Cadastro";
            this.cadastroToolStripMenuItem.ToolTipText = "Cadastro";
            // 
            // Contas
            // 
            this.Contas.Image = ((System.Drawing.Image)(resources.GetObject("Contas.Image")));
            this.Contas.Name = "Contas";
            this.Contas.Size = new System.Drawing.Size(241, 24);
            this.Contas.Text = "Contas";
            this.Contas.ToolTipText = "Cadastro Contas";
            this.Contas.Click += new System.EventHandler(this.Contas_Click);
            // 
            // Compras
            // 
            this.Compras.Image = ((System.Drawing.Image)(resources.GetObject("Compras.Image")));
            this.Compras.Name = "Compras";
            this.Compras.Size = new System.Drawing.Size(241, 24);
            this.Compras.Text = "Compras";
            this.Compras.ToolTipText = "Cadastro de Compras";
            this.Compras.Click += new System.EventHandler(this.Compras_Click_1);
            // 
            // Clientes
            // 
            this.Clientes.Image = ((System.Drawing.Image)(resources.GetObject("Clientes.Image")));
            this.Clientes.Name = "Clientes";
            this.Clientes.Size = new System.Drawing.Size(241, 24);
            this.Clientes.Text = "Clientes";
            this.Clientes.ToolTipText = "Cadastro de Clientes";
            this.Clientes.Click += new System.EventHandler(this.Clientes_Click);
            // 
            // Fornecedores
            // 
            this.Fornecedores.Image = ((System.Drawing.Image)(resources.GetObject("Fornecedores.Image")));
            this.Fornecedores.Name = "Fornecedores";
            this.Fornecedores.Size = new System.Drawing.Size(241, 24);
            this.Fornecedores.Text = "Fornecedores";
            this.Fornecedores.ToolTipText = "Cadastro de Fornecedores";
            this.Fornecedores.Click += new System.EventHandler(this.Fornecedores_Click_1);
            // 
            // Funcionarios
            // 
            this.Funcionarios.Image = ((System.Drawing.Image)(resources.GetObject("Funcionarios.Image")));
            this.Funcionarios.Name = "Funcionarios";
            this.Funcionarios.Size = new System.Drawing.Size(241, 24);
            this.Funcionarios.Text = "Funcionários";
            this.Funcionarios.ToolTipText = "Cadastro de Funcionários";
            this.Funcionarios.Click += new System.EventHandler(this.Funcionarios_Click);
            // 
            // NotaFiscal
            // 
            this.NotaFiscal.Image = ((System.Drawing.Image)(resources.GetObject("NotaFiscal.Image")));
            this.NotaFiscal.Name = "NotaFiscal";
            this.NotaFiscal.Size = new System.Drawing.Size(241, 24);
            this.NotaFiscal.Text = "Nota Fiscal";
            this.NotaFiscal.ToolTipText = "Cadastro Nota Fiscal";
            this.NotaFiscal.Click += new System.EventHandler(this.NotaFiscal_Click);
            // 
            // Produtos
            // 
            this.Produtos.Image = ((System.Drawing.Image)(resources.GetObject("Produtos.Image")));
            this.Produtos.Name = "Produtos";
            this.Produtos.Size = new System.Drawing.Size(241, 24);
            this.Produtos.Text = "Produtos";
            this.Produtos.ToolTipText = "Cadastro de Produtos";
            this.Produtos.Click += new System.EventHandler(this.Produtos_Click);
            // 
            // Transportadoras
            // 
            this.Transportadoras.Image = ((System.Drawing.Image)(resources.GetObject("Transportadoras.Image")));
            this.Transportadoras.Name = "Transportadoras";
            this.Transportadoras.Size = new System.Drawing.Size(241, 24);
            this.Transportadoras.Text = "Transportadoras";
            this.Transportadoras.ToolTipText = "Cadastro de Transportadora";
            this.Transportadoras.Click += new System.EventHandler(this.Transportadoras_Click);
            // 
            // Vendas
            // 
            this.Vendas.Image = ((System.Drawing.Image)(resources.GetObject("Vendas.Image")));
            this.Vendas.Name = "Vendas";
            this.Vendas.Size = new System.Drawing.Size(241, 24);
            this.Vendas.Text = "Vendas";
            this.Vendas.ToolTipText = "Cadastro de Vendas";
            this.Vendas.Click += new System.EventHandler(this.Vendas_Click);
            // 
            // consultasToolStripMenuItem
            // 
            this.consultasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contasToolStripMenuItem2,
            this.comprasToolStripMenuItem2,
            this.clientesToolStripMenuItem2,
            this.fornecedoresToolStripMenuItem2,
            this.funcionáriosToolStripMenuItem3,
            this.notaFiscalToolStripMenuItem2,
            this.produtosToolStripMenuItem2,
            this.transportadorasToolStripMenuItem1,
            this.vendasToolStripMenuItem2});
            this.consultasToolStripMenuItem.Font = new System.Drawing.Font("Perpetua Titling MT", 12F);
            this.consultasToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("consultasToolStripMenuItem.Image")));
            this.consultasToolStripMenuItem.Name = "consultasToolStripMenuItem";
            this.consultasToolStripMenuItem.Size = new System.Drawing.Size(134, 23);
            this.consultasToolStripMenuItem.Text = "Consultas";
            // 
            // contasToolStripMenuItem2
            // 
            this.contasToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("contasToolStripMenuItem2.Image")));
            this.contasToolStripMenuItem2.Name = "contasToolStripMenuItem2";
            this.contasToolStripMenuItem2.Size = new System.Drawing.Size(241, 24);
            this.contasToolStripMenuItem2.Text = "Contas";
            this.contasToolStripMenuItem2.Click += new System.EventHandler(this.contasToolStripMenuItem2_Click);
            // 
            // comprasToolStripMenuItem2
            // 
            this.comprasToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("comprasToolStripMenuItem2.Image")));
            this.comprasToolStripMenuItem2.Name = "comprasToolStripMenuItem2";
            this.comprasToolStripMenuItem2.Size = new System.Drawing.Size(241, 24);
            this.comprasToolStripMenuItem2.Text = "Compras";
            this.comprasToolStripMenuItem2.Click += new System.EventHandler(this.comprasToolStripMenuItem2_Click);
            // 
            // clientesToolStripMenuItem2
            // 
            this.clientesToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("clientesToolStripMenuItem2.Image")));
            this.clientesToolStripMenuItem2.Name = "clientesToolStripMenuItem2";
            this.clientesToolStripMenuItem2.Size = new System.Drawing.Size(241, 24);
            this.clientesToolStripMenuItem2.Text = "Clientes";
            this.clientesToolStripMenuItem2.Click += new System.EventHandler(this.clientesToolStripMenuItem2_Click);
            // 
            // fornecedoresToolStripMenuItem2
            // 
            this.fornecedoresToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("fornecedoresToolStripMenuItem2.Image")));
            this.fornecedoresToolStripMenuItem2.Name = "fornecedoresToolStripMenuItem2";
            this.fornecedoresToolStripMenuItem2.Size = new System.Drawing.Size(241, 24);
            this.fornecedoresToolStripMenuItem2.Text = "Fornecedores";
            this.fornecedoresToolStripMenuItem2.Click += new System.EventHandler(this.fornecedoresToolStripMenuItem2_Click);
            // 
            // funcionáriosToolStripMenuItem3
            // 
            this.funcionáriosToolStripMenuItem3.Image = ((System.Drawing.Image)(resources.GetObject("funcionáriosToolStripMenuItem3.Image")));
            this.funcionáriosToolStripMenuItem3.Name = "funcionáriosToolStripMenuItem3";
            this.funcionáriosToolStripMenuItem3.Size = new System.Drawing.Size(241, 24);
            this.funcionáriosToolStripMenuItem3.Text = "Funcionários";
            this.funcionáriosToolStripMenuItem3.Click += new System.EventHandler(this.funcionáriosToolStripMenuItem3_Click);
            // 
            // notaFiscalToolStripMenuItem2
            // 
            this.notaFiscalToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("notaFiscalToolStripMenuItem2.Image")));
            this.notaFiscalToolStripMenuItem2.Name = "notaFiscalToolStripMenuItem2";
            this.notaFiscalToolStripMenuItem2.Size = new System.Drawing.Size(241, 24);
            this.notaFiscalToolStripMenuItem2.Text = "Nota Fiscal";
            this.notaFiscalToolStripMenuItem2.Click += new System.EventHandler(this.notaFiscalToolStripMenuItem2_Click);
            // 
            // produtosToolStripMenuItem2
            // 
            this.produtosToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("produtosToolStripMenuItem2.Image")));
            this.produtosToolStripMenuItem2.Name = "produtosToolStripMenuItem2";
            this.produtosToolStripMenuItem2.Size = new System.Drawing.Size(241, 24);
            this.produtosToolStripMenuItem2.Text = "Produtos";
            this.produtosToolStripMenuItem2.Click += new System.EventHandler(this.produtosToolStripMenuItem2_Click);
            // 
            // transportadorasToolStripMenuItem1
            // 
            this.transportadorasToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("transportadorasToolStripMenuItem1.Image")));
            this.transportadorasToolStripMenuItem1.Name = "transportadorasToolStripMenuItem1";
            this.transportadorasToolStripMenuItem1.Size = new System.Drawing.Size(241, 24);
            this.transportadorasToolStripMenuItem1.Text = "Transportadoras";
            this.transportadorasToolStripMenuItem1.Click += new System.EventHandler(this.transportadorasToolStripMenuItem1_Click);
            // 
            // vendasToolStripMenuItem2
            // 
            this.vendasToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("vendasToolStripMenuItem2.Image")));
            this.vendasToolStripMenuItem2.Name = "vendasToolStripMenuItem2";
            this.vendasToolStripMenuItem2.Size = new System.Drawing.Size(241, 24);
            this.vendasToolStripMenuItem2.Text = "Vendas";
            this.vendasToolStripMenuItem2.Click += new System.EventHandler(this.vendasToolStripMenuItem2_Click);
            // 
            // ferramentasToolStripMenuItem
            // 
            this.ferramentasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.calendárioToolStripMenuItem,
            this.calculadoraToolStripMenuItem,
            this.windowsExplorerToolStripMenuItem,
            this.iToolStripMenuItem,
            this.editorDeTextoToolStripMenuItem});
            this.ferramentasToolStripMenuItem.Font = new System.Drawing.Font("Perpetua Titling MT", 12F);
            this.ferramentasToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("ferramentasToolStripMenuItem.Image")));
            this.ferramentasToolStripMenuItem.Name = "ferramentasToolStripMenuItem";
            this.ferramentasToolStripMenuItem.Size = new System.Drawing.Size(149, 23);
            this.ferramentasToolStripMenuItem.Text = "Ferramentas";
            this.ferramentasToolStripMenuItem.ToolTipText = "Ferramentas";
            // 
            // calendárioToolStripMenuItem
            // 
            this.calendárioToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("calendárioToolStripMenuItem.Image")));
            this.calendárioToolStripMenuItem.Name = "calendárioToolStripMenuItem";
            this.calendárioToolStripMenuItem.Size = new System.Drawing.Size(246, 24);
            this.calendárioToolStripMenuItem.Text = "Calendário";
            this.calendárioToolStripMenuItem.ToolTipText = "Calendário";
            this.calendárioToolStripMenuItem.Click += new System.EventHandler(this.calendárioToolStripMenuItem_Click);
            // 
            // calculadoraToolStripMenuItem
            // 
            this.calculadoraToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("calculadoraToolStripMenuItem.Image")));
            this.calculadoraToolStripMenuItem.Name = "calculadoraToolStripMenuItem";
            this.calculadoraToolStripMenuItem.Size = new System.Drawing.Size(246, 24);
            this.calculadoraToolStripMenuItem.Text = "Calculadora";
            this.calculadoraToolStripMenuItem.ToolTipText = "Calculadora";
            this.calculadoraToolStripMenuItem.Click += new System.EventHandler(this.calculadoraToolStripMenuItem_Click);
            // 
            // windowsExplorerToolStripMenuItem
            // 
            this.windowsExplorerToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("windowsExplorerToolStripMenuItem.Image")));
            this.windowsExplorerToolStripMenuItem.Name = "windowsExplorerToolStripMenuItem";
            this.windowsExplorerToolStripMenuItem.Size = new System.Drawing.Size(246, 24);
            this.windowsExplorerToolStripMenuItem.Text = "Windows Explorer";
            this.windowsExplorerToolStripMenuItem.ToolTipText = "Windows Explorer";
            this.windowsExplorerToolStripMenuItem.Click += new System.EventHandler(this.windowsExplorerToolStripMenuItem_Click);
            // 
            // iToolStripMenuItem
            // 
            this.iToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("iToolStripMenuItem.Image")));
            this.iToolStripMenuItem.Name = "iToolStripMenuItem";
            this.iToolStripMenuItem.Size = new System.Drawing.Size(246, 24);
            this.iToolStripMenuItem.Text = "Internet Explorer";
            this.iToolStripMenuItem.ToolTipText = "Internet Explorer";
            this.iToolStripMenuItem.Click += new System.EventHandler(this.iToolStripMenuItem_Click);
            // 
            // editorDeTextoToolStripMenuItem
            // 
            this.editorDeTextoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("editorDeTextoToolStripMenuItem.Image")));
            this.editorDeTextoToolStripMenuItem.Name = "editorDeTextoToolStripMenuItem";
            this.editorDeTextoToolStripMenuItem.Size = new System.Drawing.Size(246, 24);
            this.editorDeTextoToolStripMenuItem.Text = "Editor de Texto";
            this.editorDeTextoToolStripMenuItem.ToolTipText = "Editor de Texto";
            this.editorDeTextoToolStripMenuItem.Click += new System.EventHandler(this.editorDeTextoToolStripMenuItem_Click);
            // 
            // ajudaToolStripMenuItem
            // 
            this.ajudaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sobreOSistemaToolStripMenuItem});
            this.ajudaToolStripMenuItem.Font = new System.Drawing.Font("Perpetua Titling MT", 12F);
            this.ajudaToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("ajudaToolStripMenuItem.Image")));
            this.ajudaToolStripMenuItem.Name = "ajudaToolStripMenuItem";
            this.ajudaToolStripMenuItem.Size = new System.Drawing.Size(89, 23);
            this.ajudaToolStripMenuItem.Text = "Ajuda";
            this.ajudaToolStripMenuItem.ToolTipText = "Ajuda";
            // 
            // sobreOSistemaToolStripMenuItem
            // 
            this.sobreOSistemaToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("sobreOSistemaToolStripMenuItem.Image")));
            this.sobreOSistemaToolStripMenuItem.Name = "sobreOSistemaToolStripMenuItem";
            this.sobreOSistemaToolStripMenuItem.Size = new System.Drawing.Size(216, 24);
            this.sobreOSistemaToolStripMenuItem.Text = "Sobre o Sistema";
            this.sobreOSistemaToolStripMenuItem.ToolTipText = "Sobre o Sistema";
            this.sobreOSistemaToolStripMenuItem.Click += new System.EventHandler(this.sobreOSistemaToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripSeparator1,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton11,
            this.toolStripButton12,
            this.toolStripButton13,
            this.toolStripButton14,
            this.toolStripButton15,
            this.toolStripButton16,
            this.toolStripSeparator2,
            this.toolStripButton5,
            this.toolStripButton6,
            this.toolStripButton7,
            this.toolStripButton8,
            this.toolStripButton9,
            this.toolStripSeparator3,
            this.toolStripButton10});
            this.toolStrip1.Location = new System.Drawing.Point(0, 27);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(675, 33);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.AutoSize = false;
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.ToolTipText = "Fechar Sistema";
            this.toolStripButton1.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 33);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.AutoSize = false;
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton2.Text = "toolStripButton2";
            this.toolStripButton2.ToolTipText = "Cadastro Contas";
            this.toolStripButton2.Click += new System.EventHandler(this.Contas_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.AutoSize = false;
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton3.Text = "toolStripButton3";
            this.toolStripButton3.ToolTipText = "Cadastro Compras";
            this.toolStripButton3.Click += new System.EventHandler(this.Compras_Click_1);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.AutoSize = false;
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton4.Text = "toolStripButton4";
            this.toolStripButton4.ToolTipText = "Cadastro Clientes";
            this.toolStripButton4.Click += new System.EventHandler(this.Clientes_Click);
            // 
            // toolStripButton11
            // 
            this.toolStripButton11.AutoSize = false;
            this.toolStripButton11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton11.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton11.Image")));
            this.toolStripButton11.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton11.Name = "toolStripButton11";
            this.toolStripButton11.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton11.Text = "toolStripButton11";
            this.toolStripButton11.ToolTipText = "Cadastro Fornecedores";
            this.toolStripButton11.Click += new System.EventHandler(this.Fornecedores_Click_1);
            // 
            // toolStripButton12
            // 
            this.toolStripButton12.AutoSize = false;
            this.toolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton12.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton12.Image")));
            this.toolStripButton12.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton12.Name = "toolStripButton12";
            this.toolStripButton12.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton12.Text = "toolStripButton12";
            this.toolStripButton12.ToolTipText = "Cadastro Funcionários";
            this.toolStripButton12.Click += new System.EventHandler(this.Funcionarios_Click);
            // 
            // toolStripButton13
            // 
            this.toolStripButton13.AutoSize = false;
            this.toolStripButton13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton13.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton13.Image")));
            this.toolStripButton13.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton13.Name = "toolStripButton13";
            this.toolStripButton13.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton13.Text = "toolStripButton13";
            this.toolStripButton13.ToolTipText = "Cadastro Nota Fiscal";
            this.toolStripButton13.Click += new System.EventHandler(this.NotaFiscal_Click);
            // 
            // toolStripButton14
            // 
            this.toolStripButton14.AutoSize = false;
            this.toolStripButton14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton14.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton14.Image")));
            this.toolStripButton14.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton14.Name = "toolStripButton14";
            this.toolStripButton14.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton14.Text = "toolStripButton14";
            this.toolStripButton14.ToolTipText = "Cadastro Produtos";
            this.toolStripButton14.Click += new System.EventHandler(this.Produtos_Click);
            // 
            // toolStripButton15
            // 
            this.toolStripButton15.AutoSize = false;
            this.toolStripButton15.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton15.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton15.Image")));
            this.toolStripButton15.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton15.Name = "toolStripButton15";
            this.toolStripButton15.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton15.Text = "toolStripButton15";
            this.toolStripButton15.ToolTipText = "Cadastro Transportadora";
            this.toolStripButton15.Click += new System.EventHandler(this.Transportadoras_Click);
            // 
            // toolStripButton16
            // 
            this.toolStripButton16.AutoSize = false;
            this.toolStripButton16.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton16.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton16.Image")));
            this.toolStripButton16.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton16.Name = "toolStripButton16";
            this.toolStripButton16.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton16.Text = "toolStripButton16";
            this.toolStripButton16.ToolTipText = "Cadastro Vendas";
            this.toolStripButton16.Click += new System.EventHandler(this.Vendas_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 33);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.AutoSize = false;
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton5.Text = "toolStripButton5";
            this.toolStripButton5.ToolTipText = "Calendário";
            this.toolStripButton5.Click += new System.EventHandler(this.calendárioToolStripMenuItem_Click);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.AutoSize = false;
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton6.Text = "toolStripButton6";
            this.toolStripButton6.ToolTipText = "Calculadora";
            this.toolStripButton6.Click += new System.EventHandler(this.calculadoraToolStripMenuItem_Click);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.AutoSize = false;
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton7.Text = "toolStripButton7";
            this.toolStripButton7.ToolTipText = "Windows Explorer";
            this.toolStripButton7.Click += new System.EventHandler(this.windowsExplorerToolStripMenuItem_Click);
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.AutoSize = false;
            this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton8.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton8.Image")));
            this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton8.Text = "toolStripButton8";
            this.toolStripButton8.ToolTipText = "Internet Explorer";
            this.toolStripButton8.Click += new System.EventHandler(this.iToolStripMenuItem_Click);
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.AutoSize = false;
            this.toolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton9.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton9.Image")));
            this.toolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton9.Text = "toolStripButton9";
            this.toolStripButton9.ToolTipText = "Editor de Texto";
            this.toolStripButton9.Click += new System.EventHandler(this.editorDeTextoToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 33);
            // 
            // toolStripButton10
            // 
            this.toolStripButton10.AutoSize = false;
            this.toolStripButton10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton10.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton10.Image")));
            this.toolStripButton10.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton10.Name = "toolStripButton10";
            this.toolStripButton10.Size = new System.Drawing.Size(40, 30);
            this.toolStripButton10.Text = "toolStripButton10";
            this.toolStripButton10.ToolTipText = "Sobre o Sistema";
            this.toolStripButton10.Click += new System.EventHandler(this.sobreOSistemaToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3});
            this.statusStrip1.Location = new System.Drawing.Point(0, 347);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(675, 24);
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(100, 19);
            this.toolStripStatusLabel1.Text = "Bem-Vindo";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Font = new System.Drawing.Font("Perpetua Titling MT", 12F);
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(213, 19);
            this.toolStripStatusLabel2.Text = "toolStripStatusLabel2";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Font = new System.Drawing.Font("Perpetua Titling MT", 12F);
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(212, 19);
            this.toolStripStatusLabel3.Text = "toolStripStatusLabel3";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.arquivoToolStripMenuItem2,
            this.cadastroToolStripMenuItem2,
            this.consultasToolStripMenuItem1,
            this.ferramentasToolStripMenuItem2,
            this.ajudaToolStripMenuItem2});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(140, 114);
            // 
            // arquivoToolStripMenuItem2
            // 
            this.arquivoToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fecharOSistemaToolStripMenuItem});
            this.arquivoToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("arquivoToolStripMenuItem2.Image")));
            this.arquivoToolStripMenuItem2.Name = "arquivoToolStripMenuItem2";
            this.arquivoToolStripMenuItem2.Size = new System.Drawing.Size(139, 22);
            this.arquivoToolStripMenuItem2.Text = "Arquivo";
            // 
            // fecharOSistemaToolStripMenuItem
            // 
            this.fecharOSistemaToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("fecharOSistemaToolStripMenuItem.Image")));
            this.fecharOSistemaToolStripMenuItem.Name = "fecharOSistemaToolStripMenuItem";
            this.fecharOSistemaToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.fecharOSistemaToolStripMenuItem.Text = "Fechar o Sistema";
            this.fecharOSistemaToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // cadastroToolStripMenuItem2
            // 
            this.cadastroToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contasToolStripMenuItem1,
            this.comprasToolStripMenuItem1,
            this.clientesToolStripMenuItem1,
            this.fornecedoresToolStripMenuItem,
            this.funcionáriosToolStripMenuItem,
            this.notaFiscalToolStripMenuItem,
            this.produtosToolStripMenuItem1,
            this.transportadorasToolStripMenuItem,
            this.vendasToolStripMenuItem});
            this.cadastroToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("cadastroToolStripMenuItem2.Image")));
            this.cadastroToolStripMenuItem2.Name = "cadastroToolStripMenuItem2";
            this.cadastroToolStripMenuItem2.Size = new System.Drawing.Size(139, 22);
            this.cadastroToolStripMenuItem2.Text = "Cadastro";
            // 
            // contasToolStripMenuItem1
            // 
            this.contasToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("contasToolStripMenuItem1.Image")));
            this.contasToolStripMenuItem1.Name = "contasToolStripMenuItem1";
            this.contasToolStripMenuItem1.Size = new System.Drawing.Size(159, 22);
            this.contasToolStripMenuItem1.Text = "Contas";
            this.contasToolStripMenuItem1.Click += new System.EventHandler(this.Contas_Click);
            // 
            // comprasToolStripMenuItem1
            // 
            this.comprasToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("comprasToolStripMenuItem1.Image")));
            this.comprasToolStripMenuItem1.Name = "comprasToolStripMenuItem1";
            this.comprasToolStripMenuItem1.Size = new System.Drawing.Size(159, 22);
            this.comprasToolStripMenuItem1.Text = "Compras";
            this.comprasToolStripMenuItem1.Click += new System.EventHandler(this.Compras_Click_1);
            // 
            // clientesToolStripMenuItem1
            // 
            this.clientesToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("clientesToolStripMenuItem1.Image")));
            this.clientesToolStripMenuItem1.Name = "clientesToolStripMenuItem1";
            this.clientesToolStripMenuItem1.Size = new System.Drawing.Size(159, 22);
            this.clientesToolStripMenuItem1.Text = "Clientes";
            this.clientesToolStripMenuItem1.Click += new System.EventHandler(this.Clientes_Click);
            // 
            // fornecedoresToolStripMenuItem
            // 
            this.fornecedoresToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("fornecedoresToolStripMenuItem.Image")));
            this.fornecedoresToolStripMenuItem.Name = "fornecedoresToolStripMenuItem";
            this.fornecedoresToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.fornecedoresToolStripMenuItem.Text = "Fornecedores";
            this.fornecedoresToolStripMenuItem.Click += new System.EventHandler(this.Fornecedores_Click_1);
            // 
            // funcionáriosToolStripMenuItem
            // 
            this.funcionáriosToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("funcionáriosToolStripMenuItem.Image")));
            this.funcionáriosToolStripMenuItem.Name = "funcionáriosToolStripMenuItem";
            this.funcionáriosToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.funcionáriosToolStripMenuItem.Text = "Funcionários";
            this.funcionáriosToolStripMenuItem.Click += new System.EventHandler(this.Funcionarios_Click);
            // 
            // notaFiscalToolStripMenuItem
            // 
            this.notaFiscalToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("notaFiscalToolStripMenuItem.Image")));
            this.notaFiscalToolStripMenuItem.Name = "notaFiscalToolStripMenuItem";
            this.notaFiscalToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.notaFiscalToolStripMenuItem.Text = "Nota Fiscal";
            this.notaFiscalToolStripMenuItem.Click += new System.EventHandler(this.NotaFiscal_Click);
            // 
            // produtosToolStripMenuItem1
            // 
            this.produtosToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("produtosToolStripMenuItem1.Image")));
            this.produtosToolStripMenuItem1.Name = "produtosToolStripMenuItem1";
            this.produtosToolStripMenuItem1.Size = new System.Drawing.Size(159, 22);
            this.produtosToolStripMenuItem1.Text = "Produtos";
            this.produtosToolStripMenuItem1.Click += new System.EventHandler(this.Produtos_Click);
            // 
            // transportadorasToolStripMenuItem
            // 
            this.transportadorasToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("transportadorasToolStripMenuItem.Image")));
            this.transportadorasToolStripMenuItem.Name = "transportadorasToolStripMenuItem";
            this.transportadorasToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.transportadorasToolStripMenuItem.Text = "Transportadoras";
            this.transportadorasToolStripMenuItem.Click += new System.EventHandler(this.Transportadoras_Click);
            // 
            // vendasToolStripMenuItem
            // 
            this.vendasToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("vendasToolStripMenuItem.Image")));
            this.vendasToolStripMenuItem.Name = "vendasToolStripMenuItem";
            this.vendasToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.vendasToolStripMenuItem.Text = "Vendas";
            this.vendasToolStripMenuItem.Click += new System.EventHandler(this.Vendas_Click);
            // 
            // consultasToolStripMenuItem1
            // 
            this.consultasToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contasToolStripMenuItem3,
            this.comprasToolStripMenuItem3,
            this.clientesToolStripMenuItem3,
            this.fornecedoresToolStripMenuItem3,
            this.funcionáriosToolStripMenuItem2,
            this.notaFiscalToolStripMenuItem3,
            this.produtosToolStripMenuItem3,
            this.transportadoraToolStripMenuItem,
            this.vendToolStripMenuItem});
            this.consultasToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("consultasToolStripMenuItem1.Image")));
            this.consultasToolStripMenuItem1.Name = "consultasToolStripMenuItem1";
            this.consultasToolStripMenuItem1.Size = new System.Drawing.Size(139, 22);
            this.consultasToolStripMenuItem1.Text = "Consultas";
            // 
            // contasToolStripMenuItem3
            // 
            this.contasToolStripMenuItem3.Image = ((System.Drawing.Image)(resources.GetObject("contasToolStripMenuItem3.Image")));
            this.contasToolStripMenuItem3.Name = "contasToolStripMenuItem3";
            this.contasToolStripMenuItem3.Size = new System.Drawing.Size(154, 22);
            this.contasToolStripMenuItem3.Text = "Contas";
            this.contasToolStripMenuItem3.Click += new System.EventHandler(this.contasToolStripMenuItem2_Click);
            // 
            // comprasToolStripMenuItem3
            // 
            this.comprasToolStripMenuItem3.Image = ((System.Drawing.Image)(resources.GetObject("comprasToolStripMenuItem3.Image")));
            this.comprasToolStripMenuItem3.Name = "comprasToolStripMenuItem3";
            this.comprasToolStripMenuItem3.Size = new System.Drawing.Size(154, 22);
            this.comprasToolStripMenuItem3.Text = "Compras";
            this.comprasToolStripMenuItem3.Click += new System.EventHandler(this.comprasToolStripMenuItem2_Click);
            // 
            // clientesToolStripMenuItem3
            // 
            this.clientesToolStripMenuItem3.Image = ((System.Drawing.Image)(resources.GetObject("clientesToolStripMenuItem3.Image")));
            this.clientesToolStripMenuItem3.Name = "clientesToolStripMenuItem3";
            this.clientesToolStripMenuItem3.Size = new System.Drawing.Size(154, 22);
            this.clientesToolStripMenuItem3.Text = "Clientes";
            this.clientesToolStripMenuItem3.Click += new System.EventHandler(this.clientesToolStripMenuItem2_Click);
            // 
            // fornecedoresToolStripMenuItem3
            // 
            this.fornecedoresToolStripMenuItem3.Image = ((System.Drawing.Image)(resources.GetObject("fornecedoresToolStripMenuItem3.Image")));
            this.fornecedoresToolStripMenuItem3.Name = "fornecedoresToolStripMenuItem3";
            this.fornecedoresToolStripMenuItem3.Size = new System.Drawing.Size(154, 22);
            this.fornecedoresToolStripMenuItem3.Text = "Fornecedores";
            this.fornecedoresToolStripMenuItem3.Click += new System.EventHandler(this.fornecedoresToolStripMenuItem2_Click);
            // 
            // funcionáriosToolStripMenuItem2
            // 
            this.funcionáriosToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("funcionáriosToolStripMenuItem2.Image")));
            this.funcionáriosToolStripMenuItem2.Name = "funcionáriosToolStripMenuItem2";
            this.funcionáriosToolStripMenuItem2.Size = new System.Drawing.Size(154, 22);
            this.funcionáriosToolStripMenuItem2.Text = "Funcionários";
            this.funcionáriosToolStripMenuItem2.Click += new System.EventHandler(this.funcionáriosToolStripMenuItem3_Click);
            // 
            // notaFiscalToolStripMenuItem3
            // 
            this.notaFiscalToolStripMenuItem3.Image = ((System.Drawing.Image)(resources.GetObject("notaFiscalToolStripMenuItem3.Image")));
            this.notaFiscalToolStripMenuItem3.Name = "notaFiscalToolStripMenuItem3";
            this.notaFiscalToolStripMenuItem3.Size = new System.Drawing.Size(154, 22);
            this.notaFiscalToolStripMenuItem3.Text = "Nota Fiscal";
            this.notaFiscalToolStripMenuItem3.Click += new System.EventHandler(this.notaFiscalToolStripMenuItem2_Click);
            // 
            // produtosToolStripMenuItem3
            // 
            this.produtosToolStripMenuItem3.Image = ((System.Drawing.Image)(resources.GetObject("produtosToolStripMenuItem3.Image")));
            this.produtosToolStripMenuItem3.Name = "produtosToolStripMenuItem3";
            this.produtosToolStripMenuItem3.Size = new System.Drawing.Size(154, 22);
            this.produtosToolStripMenuItem3.Text = "Produtos";
            this.produtosToolStripMenuItem3.Click += new System.EventHandler(this.produtosToolStripMenuItem2_Click);
            // 
            // transportadoraToolStripMenuItem
            // 
            this.transportadoraToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("transportadoraToolStripMenuItem.Image")));
            this.transportadoraToolStripMenuItem.Name = "transportadoraToolStripMenuItem";
            this.transportadoraToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.transportadoraToolStripMenuItem.Text = "Transportadora";
            this.transportadoraToolStripMenuItem.Click += new System.EventHandler(this.transportadorasToolStripMenuItem1_Click);
            // 
            // vendToolStripMenuItem
            // 
            this.vendToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("vendToolStripMenuItem.Image")));
            this.vendToolStripMenuItem.Name = "vendToolStripMenuItem";
            this.vendToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.vendToolStripMenuItem.Text = "Vendas";
            this.vendToolStripMenuItem.Click += new System.EventHandler(this.vendasToolStripMenuItem2_Click);
            // 
            // ferramentasToolStripMenuItem2
            // 
            this.ferramentasToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.calendárioToolStripMenuItem2,
            this.calculadoraToolStripMenuItem2,
            this.windowsExplorerToolStripMenuItem2,
            this.internetExplorerToolStripMenuItem1,
            this.editorDeTextoToolStripMenuItem2});
            this.ferramentasToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("ferramentasToolStripMenuItem2.Image")));
            this.ferramentasToolStripMenuItem2.Name = "ferramentasToolStripMenuItem2";
            this.ferramentasToolStripMenuItem2.Size = new System.Drawing.Size(139, 22);
            this.ferramentasToolStripMenuItem2.Text = "Ferramentas";
            // 
            // calendárioToolStripMenuItem2
            // 
            this.calendárioToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("calendárioToolStripMenuItem2.Image")));
            this.calendárioToolStripMenuItem2.Name = "calendárioToolStripMenuItem2";
            this.calendárioToolStripMenuItem2.Size = new System.Drawing.Size(168, 22);
            this.calendárioToolStripMenuItem2.Text = "Calendário";
            this.calendárioToolStripMenuItem2.Click += new System.EventHandler(this.calendárioToolStripMenuItem_Click);
            // 
            // calculadoraToolStripMenuItem2
            // 
            this.calculadoraToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("calculadoraToolStripMenuItem2.Image")));
            this.calculadoraToolStripMenuItem2.Name = "calculadoraToolStripMenuItem2";
            this.calculadoraToolStripMenuItem2.Size = new System.Drawing.Size(168, 22);
            this.calculadoraToolStripMenuItem2.Text = "Calculadora";
            this.calculadoraToolStripMenuItem2.Click += new System.EventHandler(this.calculadoraToolStripMenuItem_Click);
            // 
            // windowsExplorerToolStripMenuItem2
            // 
            this.windowsExplorerToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("windowsExplorerToolStripMenuItem2.Image")));
            this.windowsExplorerToolStripMenuItem2.Name = "windowsExplorerToolStripMenuItem2";
            this.windowsExplorerToolStripMenuItem2.Size = new System.Drawing.Size(168, 22);
            this.windowsExplorerToolStripMenuItem2.Text = "Windows Explorer";
            this.windowsExplorerToolStripMenuItem2.Click += new System.EventHandler(this.windowsExplorerToolStripMenuItem_Click);
            // 
            // internetExplorerToolStripMenuItem1
            // 
            this.internetExplorerToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("internetExplorerToolStripMenuItem1.Image")));
            this.internetExplorerToolStripMenuItem1.Name = "internetExplorerToolStripMenuItem1";
            this.internetExplorerToolStripMenuItem1.Size = new System.Drawing.Size(168, 22);
            this.internetExplorerToolStripMenuItem1.Text = "Internet Explorer";
            this.internetExplorerToolStripMenuItem1.Click += new System.EventHandler(this.iToolStripMenuItem_Click);
            // 
            // editorDeTextoToolStripMenuItem2
            // 
            this.editorDeTextoToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("editorDeTextoToolStripMenuItem2.Image")));
            this.editorDeTextoToolStripMenuItem2.Name = "editorDeTextoToolStripMenuItem2";
            this.editorDeTextoToolStripMenuItem2.Size = new System.Drawing.Size(168, 22);
            this.editorDeTextoToolStripMenuItem2.Text = "Editor de Texto";
            this.editorDeTextoToolStripMenuItem2.Click += new System.EventHandler(this.editorDeTextoToolStripMenuItem_Click);
            // 
            // ajudaToolStripMenuItem2
            // 
            this.ajudaToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sobreOSistemaToolStripMenuItem2});
            this.ajudaToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("ajudaToolStripMenuItem2.Image")));
            this.ajudaToolStripMenuItem2.Name = "ajudaToolStripMenuItem2";
            this.ajudaToolStripMenuItem2.Size = new System.Drawing.Size(139, 22);
            this.ajudaToolStripMenuItem2.Text = "Ajuda";
            // 
            // sobreOSistemaToolStripMenuItem2
            // 
            this.sobreOSistemaToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("sobreOSistemaToolStripMenuItem2.Image")));
            this.sobreOSistemaToolStripMenuItem2.Name = "sobreOSistemaToolStripMenuItem2";
            this.sobreOSistemaToolStripMenuItem2.Size = new System.Drawing.Size(158, 22);
            this.sobreOSistemaToolStripMenuItem2.Text = "Sobre o Sistema";
            this.sobreOSistemaToolStripMenuItem2.Click += new System.EventHandler(this.sobreOSistemaToolStripMenuItem_Click);
            // 
            // FrmPrinc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(675, 371);
            this.ContextMenuStrip = this.contextMenuStrip2;
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmPrinc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Principal";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.contextMenuStrip2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem arquivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cadastroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Contas;
        private System.Windows.Forms.ToolStripMenuItem Compras;
        private System.Windows.Forms.ToolStripMenuItem Clientes;
        private System.Windows.Forms.ToolStripMenuItem ferramentasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calendárioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calculadoraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem windowsExplorerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editorDeTextoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ajudaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sobreOSistemaToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButton10;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolStripMenuItem Fornecedores;
        private System.Windows.Forms.ToolStripMenuItem Funcionarios;
        private System.Windows.Forms.ToolStripMenuItem NotaFiscal;
        private System.Windows.Forms.ToolStripMenuItem Produtos;
        private System.Windows.Forms.ToolStripMenuItem Transportadoras;
        private System.Windows.Forms.ToolStripMenuItem Vendas;
        private System.Windows.Forms.ToolStripButton toolStripButton11;
        private System.Windows.Forms.ToolStripButton toolStripButton12;
        private System.Windows.Forms.ToolStripButton toolStripButton13;
        private System.Windows.Forms.ToolStripButton toolStripButton14;
        private System.Windows.Forms.ToolStripButton toolStripButton15;
        private System.Windows.Forms.ToolStripButton toolStripButton16;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem arquivoToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem fecharOSistemaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cadastroToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem contasToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem comprasToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem clientesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem fornecedoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funcionáriosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem notaFiscalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem produtosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem transportadorasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vendasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ferramentasToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem calendárioToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem calculadoraToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem windowsExplorerToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem internetExplorerToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem editorDeTextoToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem ajudaToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem sobreOSistemaToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem consultasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem contasToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem comprasToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem clientesToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem fornecedoresToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem notaFiscalToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem produtosToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem transportadorasToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem vendasToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem consultasToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem contasToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem comprasToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem clientesToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem fornecedoresToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem funcionáriosToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem notaFiscalToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem produtosToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem transportadoraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vendToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funcionáriosToolStripMenuItem3;
    }
}